-- Define the sprite entity

minetest.register_entity("sprite_entity_mod:sprite_entity", {
    initial_properties = {
        physical = true,
        visual = "sprite",
        visual_size = {x = 1, y = 1},
        textures = {"unknown_object.png"},
        collisionbox = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
        on_punch = function(self, puncher)
            -- Spawn a new entity when punched
            local pos = self.object:get_pos()
            local new_entity = minetest.add_entity(pos, "sprite_entity_mod:sprite_entity")
            if new_entity then
                -- Give the puncher an item to spawn the entity
                local inv = puncher:get_inventory()
                inv:add_item("main", "sprite_entity_mod:spawn_item")
            end
            self.object:remove()
        end,
    },
})

-- Register the spawn item

minetest.register_craftitem("sprite_entity_mod:spawn_item", {
    description = "Sprite Entity Spawn Item",
    inventory_image = "unknown_item.png",
    on_place = function(itemstack, placer, pointed_thing)
        -- Spawn the entity when the spawn item is placed
        if pointed_thing.type == "node" then
            local pos = minetest.get_pointed_thing_position(pointed_thing, true)
            minetest.add_entity(pos, "sprite_entity_mod:sprite_entity")
        end
        itemstack:take_item()
        return itemstack
    end,
})

-- Register the crafting recipe for the spawn item

minetest.register_craft({
    output = "sprite_entity_mod:spawn_item",
    recipe = {
        {"default:paper", "default:paper", "default:paper"},
        {"default:paper", "default:stick", "default:paper"},
        {"default:paper", "default:paper", "default:paper"},
    },
})