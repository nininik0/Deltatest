


-- Register the frame node
minetest.register_node("paintings:frame", {
    description = "Painting Frame",
    tiles = {"wood.png"},
    drawtype = "signlike",
    walkable = false,
    paramtype2 = "wallmounted",
    groups = {dig_immediate=2},
    on_rightclick = function(pos, node, clicker)
        local name = clicker:get_player_name()

        -- Store the frame position and its param2 for orientation
        clicker:get_meta():set_string("frame_pos", minetest.pos_to_string(pos))
        clicker:get_meta():set_int("frame_param2", node.param2)

        -- Open a formspec with 15 painting options
        minetest.show_formspec(name, "paintings:frame", "size[9,9]" ..
            "label[0.5,0.5;Choose a Painting]" ..
            "button_exit[1,1;4,1;painting_1; Delta Island]" ..
            "button_exit[1,1.5;4,1;painting_2; Cave]" ..
            "button_exit[1,2;4,1;painting_3;Player]" ..
            "button_exit[1,2.5;4,1;painting_4;Hill]" ..
            "button_exit[1,3;4,1;painting_5;Shore]" ..
            "button_exit[1,3.5;4,1;painting_6;House]" ..
            "button_exit[1,4;4,1;painting_7;Beta]" ..
            "button_exit[1,4.5;4,1;painting_8;Bridge]" ..
            "button_exit[1,5;4,1;painting_9;C55]" ..
            "button_exit[1,5.5;4,1;painting_10;Pushkin]" ..
            "button_exit[1,6;4,1;painting_11;Minetest]" ..
            "button_exit[1,6.5;4,1;painting_12;Lonely Tree Island]" ..
            "button_exit[1,7;4,1;painting_13;Cat]" ..
            "button_exit[1,7.5;4,1;painting_14;Mountain]" ..
            "button_exit[1,8;4,1;painting_15;Coast]"
        )
    end,
})

-- Define the paintings and their nodes
for i = 1, 15 do
    minetest.register_node("paintings:painting_" .. i, {
        description = "Painting " .. i,
        tiles = {"paintings_painting_" .. i .. ".png"},
        drawtype = "signlike",
        paramtype2 = "wallmounted",
       walkable = false,
        paramtype = "light",
        drop = 'paintings:frame',
        groups = {dig_immediate = 2, not_in_creative_inventory = 1, air_equivalent=1},
    })
end

-- Handle painting selection from the formspec
minetest.register_on_player_receive_fields(function(player, formname, fields)
    if formname == "paintings:frame" then
        local pos = minetest.string_to_pos(player:get_meta():get_string("frame_pos"))
        local param2 = player:get_meta():get_int("frame_param2")
        if not pos then return end

        for i = 1, 15 do
            if fields["painting_" .. i] then
                minetest.set_node(pos, {name = "paintings:painting_" .. i, param2 = param2})
                break
            end
        end
    end
end)