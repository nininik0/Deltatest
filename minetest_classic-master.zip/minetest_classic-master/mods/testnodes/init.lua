local path = minetest.get_modpath(minetest.get_current_modname())

dofile(path.."/drawtypes.lua")
dofile(path.."/meshes.lua")
dofile(path.."/nodeboxes.lua")
dofile(path.."/properties.lua")
dofile(path.."/light.lua")
dofile(path.."/overlays.lua")
