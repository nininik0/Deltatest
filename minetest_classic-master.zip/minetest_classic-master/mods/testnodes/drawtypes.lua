

local S = minetest.get_translator("testnodes")

-- A regular cube
minetest.register_node("testnodes:normal", {
	description = S("Normal"),
	drawtype = "normal",
	tiles = { "testnodes_normal.png" },

	groups = { dig_immediate = 3 },
})




minetest.register_node("testnodes:allfaces", {
	description = S("yellow frames"),
	drawtype = "allfaces",
	paramtype = "light",
	tiles = { "testnodes_allfaces.png" },

	groups = { dig_immediate = 3 },
})

minetest.register_node("testnodes:allfaces_optional", {
	description = S("blue frames"),
	drawtype = "allfaces_optional",
	paramtype = "light",
	tiles = { "testnodes_allfaces_optional.png" },

	groups = { dig_immediate = 3 },
})



minetest.register_node("testnodes:fencelike", {
	description = S("Fence 2"),
	drawtype = "fencelike",
	paramtype = "light",
	tiles = { "testnodes_fencelike.png" },

	groups = { dig_immediate = 3 },
})

minetest.register_node("testnodes:torchlike_wallmounted", {
	description = S("Wallmounted Torchlike Drawtype Test Node"),
	drawtype = "torchlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	tiles = {
		"testnodes_torchlike_floor.png",
		"testnodes_torchlike_ceiling.png",
		"testnodes_torchlike_wall.png",
	},


	walkable = false,
	sunlight_propagates = true,
	groups = { dig_immediate = 3 },
})


-- param2 will change height
minetest.register_node("testnodes:plantlike_leveled", {
	description = S("Leveled Plantlike Drawtype Test Node"),
	drawtype = "plantlike",
	paramtype = "light",
	paramtype2 = "leveled",
	tiles = {
		{ name = "testnodes_plantlike_leveled.png", tileable_vertical = true },
	},


	-- We set a default param2 here only for convenience, to make the "plant" visible after placement
	place_param2 = 8,
	walkable = false,
	sunlight_propagates = true,
	groups = { dig_immediate = 3 },
})

-- param2 changes shape
minetest.register_node("testnodes:plantlike_meshoptions", {
	description = S("Meshoptions Plantlike Drawtype Test Node"),
	drawtype = "plantlike",
	paramtype = "light",
	paramtype2 = "meshoptions",
	tiles = { "testnodes_plantlike_meshoptions.png" },


	walkable = false,
	groups = { dig_immediate = 3 },
})

minetest.register_node("testnodes:liquid_waving", {
	description = S("Waving Source Liquid Drawtype Test Node"),
	drawtype = "liquid",
	paramtype = "light",
	tiles = {
		"testnodes_liquidsource.png^[colorize:#0000FF:127",
	},
	special_tiles = {
		{name="testnodes_liquidsource.png^[colorize:#0000FF:127", backface_culling=false},
		{name="testnodes_liquidsource.png^[colorize:#0000FF:127", backface_culling=true},
	},
	use_texture_alpha = "blend",
	waving = 3,


	walkable = false,
	liquid_range = 10,
	liquid_viscosity = 0,
	liquid_alternative_flowing = "testnodes:liquid_flowing_waving",
	liquid_alternative_source = "testnodes:liquid_waving",
	groups = { dig_immediate = 3 },
})
minetest.register_node("testnodes:liquid_flowing_waving", {
	description = S("Waving Flowing Liquid Drawtype Test Node"),
	drawtype = "flowingliquid",
	paramtype = "light",
	paramtype2 = "flowingliquid",
	tiles = {
		"testnodes_liquidflowing.png^[colorize:#0000FF:127",
	},
	special_tiles = {
		{name="testnodes_liquidflowing.png^[colorize:#0000FF:127", backface_culling=false},
		{name="testnodes_liquidflowing.png^[colorize:#0000FF:127", backface_culling=false},
	},
	use_texture_alpha = "blend",
	waving = 3,


	walkable = true,
	liquid_range = 9,
	liquid_viscosity = 0,
	liquid_alternative_flowing = "testnodes:liquid_flowing_waving",
	liquid_alternative_source = "testnodes:liquid_waving",
	groups = { dig_immediate = 3 },
})

-- Invisible node
minetest.register_node("testnodes:airlike", {
	description = S("Airlike Drawtype Test Node"),
	drawtype = "airlike",
	paramtype = "light",


	walkable = true,
	groups = { dig_immediate = 3 },
	sunlight_propagates = true,
})
