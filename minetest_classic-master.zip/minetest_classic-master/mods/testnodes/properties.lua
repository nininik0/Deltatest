-- Test Nodes: Node property tests

local S = minetest.get_translator("testnodes") 

-- Jump disabled
minetest.register_node("testnodes:nojump", {
	description = S("Non-jumping Node").."\n"..
		S("You can't jump on it"),
	groups = {disable_jump=1, dig_immediate=3},
	tiles = {"testnodes_nojump_top.png", "testnodes_nojump_side.png"},
})

-- Jump disabled plant
minetest.register_node("testnodes:nojump_walkable", {
	description = S("Non-jumping Plant Node").."\n"..
		S("You can't jump while your feet are in it"),
	drawtype = "plantlike",
	groups = {disable_jump=1, dig_immediate=3},
	walkable = false,
	tiles = {"testnodes_nojump_top.png"},
})

-- Climbable up and down with jump and sneak keys
minetest.register_node("testnodes:climbable", {
	description = S("Climbable Node").."\n"..
		S("You can climb up and down"),
	climbable = true,
	walkable = false,


	paramtype = "light",
	sunlight_propagates = true,
	is_ground_content = false,
	tiles ={"testnodes_climbable_side.png"},
	drawtype = "allfaces",
	groups = {dig_immediate=3},
})

-- Climbable only downwards with sneak key
minetest.register_node("testnodes:climbable_nojump", {
	description = S("Downwards-climbable Node").."\n"..
		S("You can climb only downwards"),
	climbable = true,
	walkable = false,

	groups = {disable_jump=1, dig_immediate=3},
	drawtype = "allfaces",
	tiles ={"testnodes_climbable_nojump_side.png"},
	paramtype = "light",
	sunlight_propagates = true,
})

-- A liquid in which you can't rise
minetest.register_node("testnodes:liquid_nojump", {
	description = S("Non-jumping Liquid Source Node").."\n"..
		S("Swimmable liquid, but you can't swim upwards"),
	liquidtype = "source",
	liquid_range = 1,
	liquid_viscosity = 0,
	liquid_alternative_flowing = "testnodes:liquidflowing_nojump",
	liquid_alternative_source = "testnodes:liquid_nojump",
	liquid_renewable = false,
	groups = {disable_jump=1, dig_immediate=3},
	walkable = false,

	drawtype = "liquid",
	tiles = {"testnodes_liquidsource.png^[colorize:#FF0000:127"},
	special_tiles = {
		{name = "testnodes_liquidsource.png^[colorize:#FF0000:127", backface_culling = false},
		{name = "testnodes_liquidsource.png^[colorize:#FF0000:127", backface_culling = true},
	},
	use_texture_alpha = "blend",
	paramtype = "light",
	pointable = false,
	liquids_pointable = true,
	buildable_to = true,
	is_ground_content = false,
	post_effect_color = {a = 70, r = 255, g = 0, b = 200},
})

-- A liquid in which you can't rise (flowing variant)
minetest.register_node("testnodes:liquidflowing_nojump", {
	description = S("Non-jumping Flowing Liquid Node").."\n"..
		S("Swimmable liquid, but you can't swim upwards"),
	liquidtype = "flowing",
	liquid_range = 1,
	liquid_viscosity = 0,
	liquid_alternative_flowing = "testnodes:liquidflowing_nojump",
	liquid_alternative_source = "testnodes:liquid_nojump",
	liquid_renewable = false,
	groups = {disable_jump=1, dig_immediate=3},
	walkable = false,


	drawtype = "flowingliquid",
	tiles = {"testnodes_liquidflowing.png^[colorize:#FF0000:127"},
	special_tiles = {
		{name = "testnodes_liquidflowing.png^[colorize:#FF0000:127", backface_culling = false},
		{name = "testnodes_liquidflowing.png^[colorize:#FF0000:127", backface_culling = false},
	},
	use_texture_alpha = "blend",
	paramtype = "light",
	paramtype2 = "flowingliquid",
	pointable = false,
	liquids_pointable = true,
	buildable_to = true,
	is_ground_content = false,
	post_effect_color = {a = 70, r = 255, g = 0, b = 200},
})

-- Nodes that modify fall damage (various damage modifiers)
for i=-100, 100, 25 do
	if i ~= 0 then
		local subname, descnum
		if i < 0 then
			subname = "NEG"..string.format("%03d", math.abs(i))
			descnum = tostring(i)
		else
			subname = string.format("%03d", i)
			descnum = S("+@1", i)
		end
		local tex, color, desc
		if i > 0 then
			local val = math.floor((i/100)*255)
			tex = "testnodes_fall_damage_plus.png"
			color = { b=0, g=255-val, r=255, a=255 }
			desc = S("Fall (+@1)", i)
		else
			tex = "testnodes_fall_damage_minus.png"
			if i == -100 then
				color = { r=0, b=0, g=255, a=255 }
			else
				local val = math.floor((math.abs(i)/100)*255)
				color = { r=0, b=255, g=255-val, a=255 }
			end
			desc = S("Fall (-@1)", math.abs(i))
		end
		minetest.register_node("testnodes:damage"..subname, {
			description = desc,
			groups = {fall_damage_add_percent=i, dig_immediate=3},


			tiles = { tex },
			is_ground_content = false,
			color = color,
		})
	end
end

-- Bouncy nodes (various bounce levels)
local MAX_BOUNCE_JUMPY = 180
local MAX_BOUNCE_NONJUMPY = 140
for i=-MAX_BOUNCE_NONJUMPY, MAX_BOUNCE_JUMPY, 20 do
	if i ~= 0 then
		local desc
		local val = math.floor(((i-20)/200)*255)
		local val2 = math.max(0, 200 - val)
		local num = string.format("%03d", math.abs(i))
		if i > 0 then
			desc = S("? (@1%), !", i).."\n"..
				S("123")
			color = { r=255-val, g=255-val, b=255, a=255 }
		else
			desc = S(" ? (@1), ?", math.abs(i)).."\n"..
				S("!")
			color = { r=val, g=255, b=val, a=255 }
			num = "NEG"..num
		end
		minetest.register_node("testnodes:bouncy"..num, {
			description = desc,
			groups = {bouncy=i, dig_immediate=3},


			color = color,
			tiles ={"testnodes_bouncy.png"},
			is_ground_content = false,
		})
	end
end

-- Slippery nodes (various slippery levels)
for i=1, 5 do
	minetest.register_node("testnodes:slippery"..i, {
		description = S("Slip (@1)", i),
		tiles ={"testnodes_slippery.png"},
		is_ground_content = false,
		groups = {slippery=i, dig_immediate=3},
		color = { r=0, g=255, b=math.floor((i/5)*255), a=255 },
	})
end

minetest.register_node("testnodes:climbable_move_resistance_4", {
	description = S("Climbable Move-resistant Node (4)").."\n"..
		S("You can climb up and down; reduced movement speed"),
	walkable = false,
	climbable = true,
	move_resistance = 4,

	drawtype = "alltaces",
	paramtype = "light",
	sunlight_propagates = true,
	tiles = {"testnodes_climbable_resistance_side.png"},
	is_ground_content = false,
	groups = { dig_immediate = 3 },
})

-- By placing something on the node, the node itself will be replaced
minetest.register_node("testnodes:buildable_to", {
	description = S("\"buildable_to\" Node").."\n"..
		S("Placing a node on it will replace it"),
	buildable_to = true,
	tiles = {"testnodes_buildable_to.png"},
	is_ground_content = false,
	groups = {dig_immediate=3},
})

-- Nodes that deal damage to players that are inside them.
-- Negative damage nodes should heal.
for d=-3,3 do
	if d ~= 0 then
		local sub, tile, desc
		if d > 0 then
			sub = tostring(d)
			tile = "testnodes_damage.png"
			desc = S("Damage  (@1 damage per second)", d)
		else
			sub = "m" .. tostring(math.abs(d))
			tile = "testnodes_damage_neg.png"
			desc = S("Healing  (@1 HP per second)", math.abs(d))
		end
		if math.abs(d) == 2 then
			tile = tile .. "^[colorize:#000000:70"
		elseif math.abs(d) == 3 then
			tile = tile .. "^[colorize:#000000:140"
		end
		minetest.register_node("testnodes:damage_"..sub, {
			description = desc,
			damage_per_second = d,


			walkable = false,
			is_ground_content = false,
			drawtype = "allfaces",
			paramtype = "light",
			sunlight_propagates = true,
			tiles = { tile },
			groups = {dig_immediate=3},
		})
	end
end

-- Causes drowning damage
minetest.register_node("testnodes:drowning_1", {
	description = S("Drowning Node (@1 damage)", 1).."\n"..
		S("You'll drown inside it"),
	drowning = 1,


	walkable = false,
	is_ground_content = false,
	drawtype = "allfaces",
	paramtype = "light",
	sunlight_propagates = true,
	tiles = { "testnodes_drowning.png" },
	groups = {dig_immediate=3},
})

