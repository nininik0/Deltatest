# Minetest Greenscreen Mod
Adds various brightly-coloured and glowing nodes intended to be used to easily chroma-key out in screenshots or video. They can only be obtained in creative or with commands.

For best results, disable antialiasing!

This is a fork of the old [`greenscreen`](https://content.minetest.net/packages/Glory/greenscreen/) mod by Glory with various improvements added to it, but both are fully compatible with eachother.

## Colours
| Colour |   Hex   |
|:------:|:-------:|
| Black  | #000000 |
| Grey   | #888888 |
| White  | #FFFFFF |
| Red    | #FF0000 |
| Orange | #FF8800 |
| Yellow | #FFFF00 |
| Green  | #00FF00 |
| Cyan   | #00FFFF |
| Blue   | #0000FF |
| Purple | #FF00FF |
