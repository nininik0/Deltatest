-- Override player's on_die function to drop items on death
local function drop_items_on_death(player)
	local pos = player:get_pos()

	-- Drop each item in the player's inventory
	local inventory = player:get_inventory()
	for _, stack in ipairs(inventory:get_list("main")) do
		if not stack:is_empty() then
			minetest.add_item(pos, stack)
		end
	end

	-- Clear the player's inventory
	inventory:set_list("main", {})
	inventory:set_list("craft", {})
end

minetest.register_on_dieplayer(drop_items_on_death)


minetest.register_on_joinplayer(function(player)
    player:set_properties({
        use_texture_alpha = true,
    })
end)