-- Crafting --------------------
minetest.register_craft({
	output = "woolmod:wool 4",
	recipe = {
		{"default:rat", "default:rat"},
		{"default:rat", "default:rat"},
	}
})

minetest.register_craft({
	output = "woolmod:green_dye 10",
	recipe = {
		{"default:cactus", "default:cactus"},
	}
})

minetest.register_craft({
	output = "woolmod:red_dye 10",
	recipe = {
		{"default:apple", "default:apple"},
	}
})

minetest.register_craft({
	output = "woolmod:blue_dye 10",
	recipe = {
		{"default:dirt", "colorful_flora_mod:blue_flower"},
	}
})

minetest.register_craft({
	output = "woolmod:blue 1",
	recipe = {
		{"woolmod:wool", "woolmod:blue_dye"},
	}
})

minetest.register_craft({
	output = "woolmod:yellow_dye 10",
	recipe = {
		{"woolmod:green_dye", "woolmod:blue_dye"},
	}
})

minetest.register_craft({
	output = "woolmod:yellow_wool 1",
	recipe = {
		{"woolmod:wool", "woolmod:yellow_dye"},
	}
})

minetest.register_craft({
	output = "woolmod:green_wool 1",
	recipe = {
		{"woolmod:wool", "woolmod:green_dye"},
	}
})

minetest.register_craft({
	output = "woolmod:red_wool 1",
	recipe = {
		{"woolmod:wool", "woolmod:red_dye"},
	}
})

-- Tools --------------------
-- Craftitems --------------------
minetest.register_craftitem("woolmod:red_dye", {
	description = "Red Dye",
	inventory_image = "red_dye.png",
})

minetest.register_craftitem("woolmod:green_dye", {
	description = "Green Dye",
	inventory_image = "green_dye.png",
})

minetest.register_craftitem("woolmod:blue_dye", {
	description = "Blue Dye",
	inventory_image = "blue_dye.png",
})



-- Nodes --------------------
minetest.register_node("woolmod:wool", {
	description = "Wool",
	tiles = {"wool.png"},
	inventory_image = minetest.inventorycube("wool.png", "wool.png", "wool.png"),
	is_ground_content = false,
	groups = {dig_immediate = 2},
})

minetest.register_node("woolmod:green_wool", {
	description = "Green Wool",
	tiles = {"green_wool.png"},
	inventory_image = minetest.inventorycube("green_wool.png", "green_wool.png", "green_wool.png"),
	is_ground_content = false,
	groups = {dig_immediate = 2},
})

minetest.register_node("woolmod:red_wool", {
	description = "Red Wool",
	tiles = {"red_wool.png"},
	inventory_image = minetest.inventorycube("red_wool.png", "red_wool.png", "red_wool.png"),
	is_ground_content = false,
	groups = {dig_immediate = 2},
})

minetest.register_node("woolmod:blue", {
	description = "Blue Wool",
	tiles = {"blue_wool.png"},
	inventory_image = minetest.inventorycube("blue_wool.png", "blue_wool.png", "blue_wool.png"),
	is_ground_content = false,
	groups = {dig_immediate= 2},
})

minetest.register_craftitem("woolmod:yellow_dye", {
	description = "Yellow Dye",
	inventory_image = "yellow_dye.png", -- Fix this if it was meant to be green_dye.png
})

-- Nodes --------------------
minetest.register_node("woolmod:yellow_wool", {
	description = "Yellow Wool",
	tiles = {"yellow_wool.png"},
	inventory_image = minetest.inventorycube("yellow_wool.png", "yellow_wool.png", "yellow_wool.png"),
	is_ground_content = false,
	groups = {dig_immediate = 2},
})
