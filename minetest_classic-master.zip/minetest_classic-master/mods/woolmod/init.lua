--Crafting--------------------
minetest.register_craft({
	output = "woolmod:wool 4",
	recipe = {
		{'craft "rat"', 'craft "rat"'},
		{'craft "rat"', 'craft "rat"'},
	}
})
minetest.register_craft({
	output = 'craft "woolmod:green_dye" 10',
	recipe = {
		{'node "default:cactus"', 'node "default:cactus"'},
	}
})
minetest.register_craft({
	output = 'craft "woolmod:red_dye" 10',
	recipe = {
		{'craft "default:apple"', 'craft "default:apple"'},
	}
})
minetest.register_craft({
	output = 'craft "woolmod:blue_dye" 10',
	recipe = {
		{'node "default:dirt"', 'node "default:dirt"'},
	}
})
minetest.register_craft({
	output = 'node "woolmod:blue" 1',
	recipe = {
		{'node "woolmod:wool"', 'craft "woolmod:brown_dye"'},
	}
})
minetest.register_craft({
	output = 'node "woolmod:green_wool" 1',
	recipe = {
		{'node "woolmod:wool"', 'craft "woolmod:green_dye"'},
	}
})
minetest.register_craft({
	output = 'node "woolmod:red_wool" 1',
	recipe = {
		{'node "woolmod:wool"', 'craft "woolmod:red_dye"'},
	}
})
--Tools--------------------
--Craftitem--------------------
minetest.register_craftitem("woolmod:red_dye", {
	image = "red_dye.png",
	on_place_on_ground = minetest.craftitem_place_item,
})

minetest.register_craftitem("woolmod:green_dye", {
	image = "green_dye.png",
	on_place_on_ground = minetest.craftitem_place_item,
})

minetest.register_craftitem("woolmod:blue_dye", {
	image = "blue_dye.png",
	on_place_on_ground = minetest.craftitem_place_item,
})
minetest.register_craftitem("woolmod:dark_green", {
	image = "gween_dye.png",
	on_place_on_ground = minetest.craftitem_place_item,
})

--Node--------------------
minetest.register_node("woolmod:wool", {
	tiles = {"wool.png"},
	inventory_image = minetest.inventorycube("wool.png"),
	is_ground_content = true,
	groups = {hand = 2}
})
minetest.register_node("woolmod:green_wool", {
	tiles = {"green_wool.png"},
	inventory_image = minetest.inventorycube("green_wool.png"),
	is_ground_content = true,
	groups = {hand = 1}
})
minetest.register_node("woolmod:red_wool", {
	tiles = {"red_wool.png"},
	inventory_image = minetest.inventorycube("red_wool.png"),
	is_ground_content = true,
	groups = {hand = 2}
})
minetest.register_node("woolmod:blue", {
	tiles = {"blue_wool.png"},
	inventory_image = minetest.inventorycube("blue_wool.png"),
	is_ground_content = true,
	groups = {hand = 1}
})