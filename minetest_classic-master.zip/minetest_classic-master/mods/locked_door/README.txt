This mod is meant to be used with node protection because
the door can be dug. Everything in this mod is licensed
under the WTFPL.
