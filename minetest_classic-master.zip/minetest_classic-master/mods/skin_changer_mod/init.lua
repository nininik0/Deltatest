local modpath = minetest.get_modpath("skin_changer_mod") .. "/textures"

-- Function to get available skins from the textures directory
local function get_available_skins(prefix)
    local skins = {}
    local all_files = minetest.get_dir_list(modpath, false)
    for _, filename in ipairs(all_files) do
        if filename:match("^" .. prefix .. ".*%.png$") then
            table.insert(skins, filename)
        end
    end
    return skins
end

minetest.register_craftitem("skin_changer_mod:skin_changer", {
    description = "Skin Changer",
    inventory_image = "skin_changer.png",
    on_use = function(itemstack, user, pointed_thing)
        if user and user:is_player() and user:get_properties().visual_size.y > 1 then
            local formspec = "size[8,8]" ..
                "label[0,0;Select a front skin:]" ..
                "label[0,4;Select a back skin:]" ..
                "button_exit[6,7.5;2,1;exit;Exit]"

            -- Get dynamically available skins
            local front_skins = get_available_skins("front_")
            local back_skins = get_available_skins("back_")

            local function generate_skin_buttons(skins, start_x, start_y, prefix)
                local x, y = start_x, start_y
                for i, skin in ipairs(skins) do
                    formspec = formspec .. "image_button[" .. x .. "," .. y .. ";1,1;" .. skin .. ";" .. prefix .. "_skin_" .. i .. ";;false;false;]"
                    x = x + 1
                    if x >= 8 then
                        x = start_x
                        y = y + 1
                    end
                end
                return y + 1
            end

            local front_y = generate_skin_buttons(front_skins, 0, 1, "front")
            local back_y = generate_skin_buttons(back_skins, 0, 4, "back")

            local max_y = math.max(front_y, back_y)
            if max_y > 8 then
                formspec = "size[8," .. max_y + 1 .. "]" .. formspec
            end

            minetest.show_formspec(user:get_player_name(), "skin_changer_mod:skin_changer_formspec", formspec)
        end
    end,
})

minetest.register_on_player_receive_fields(function(player, formname, fields)
    if formname == "skin_changer_mod:skin_changer_formspec" then
        if player:get_properties().visual_size.y > 1 then
            local front_skins = get_available_skins("front_")
            local back_skins = get_available_skins("back_")
            
            for field, _ in pairs(fields) do
                if field:match("^front_skin_%d+$") then
                    local index = tonumber(field:match("%d+"))
                    if front_skins[index] then
                        local props = player:get_properties()
                        props.textures[1] = front_skins[index]
                        player:set_properties(props)
                        player:get_meta():set_string("front_skin", front_skins[index])
                        minetest.chat_send_player(player:get_player_name(), "Front skin changed!")
                    end
                end
                if field:match("^back_skin_%d+$") then
                    local index = tonumber(field:match("%d+"))
                    if back_skins[index] then
                        local props = player:get_properties()
                        props.textures[2] = back_skins[index]
                        player:set_properties(props)
                        player:get_meta():set_string("back_skin", back_skins[index])
                        minetest.chat_send_player(player:get_player_name(), "Back skin changed!")
                    end
                end
            end
        end
    end
end)

minetest.register_on_joinplayer(function(player)
    local front_skin = player:get_meta():get_string("front_skin")
    local back_skin = player:get_meta():get_string("back_skin")
    local props = player:get_properties()

    if front_skin ~= "" then
        props.textures[1] = front_skin
    end
    if back_skin ~= "" then
        props.textures[2] = back_skin
    end
    player:set_properties(props)
end)


-- Mace
minetest.register_tool(":basetools:mace", {
    description = "Mace",
    inventory_image = "mace.png",
    tool_capabilities = {
        full_punch_interval = 1.0,
        max_drop_level = 1,
        groupcaps = {
            cracky = {times={[1]=2.0, [2]=1.0, [3]=0.50}, uses=30, maxlevel=2},
        },
        damage_groups = {fleshy=9},
    },
    sound = {breaks = "default_tool_breaks"},
})

-- Black Axe
minetest.register_tool(":basetools:black_axe", {
    description = "Black Axe",
    inventory_image = "black_axe.png",
    tool_capabilities = {
        full_punch_interval = 0.2,
        max_drop_level = 1,
        groupcaps = {
            wood = {times={[1]=1.5, [2]=0.7, [5]=0.4}, uses=25, maxlevel=2},
        },
        damage_groups = {fleshy=12},
    },
    sound = {breaks = "default_tool_breaks"},
})

-- Black Sword
minetest.register_tool(":basetools:black_sword", {
    description = "Black Sword",
    inventory_image = "black_sword.png",
    tool_capabilities = {
        full_punch_interval = 0.2,
        max_drop_level = 1,
        groupcaps = {
            snappy = {times={[1]=1.4, [2]=0.5, [3]=0.2}, uses=40, maxlevel=3},
        },
        damage_groups = {fleshy=11},
    },
    sound = {breaks = "default_tool_breaks"},
})

-- Purple Spear
minetest.register_tool(":basetools:purple_spear", {
    description = "Purple Spear",
    inventory_image = "staff.png",
    tool_capabilities = {
        full_punch_interval = 1.0,
        max_drop_level = 1,
        groupcaps = {
            stabby = {times={[1]=1.8, [2]=0.8, [3]=0.4}, uses=30, maxlevel=2},
        },
        damage_groups = {fleshy=10},
    },
    sound = {breaks = "default_tool_breaks"},
})

-- Black Spear
minetest.register_tool(":basetools:black_spear", {
    description = "Black Spear",
    inventory_image = "Bolt_2.png",
    tool_capabilities = {
        full_punch_interval = 1.1,
        max_drop_level = 1,
        groupcaps = {
            stabby = {times={[1]=1.7, [2]=0.7, [3]=0.3}, uses=35, maxlevel=3},
        },
        damage_groups = {fleshy=12},
    },
    sound = {breaks = "default_tool_breaks"},
})