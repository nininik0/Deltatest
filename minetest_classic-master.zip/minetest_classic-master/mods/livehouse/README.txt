Author: neko259
License: GPLv3

Define structures in structures.txt as in example. Format:

# House name (define before every house)
; Comment
x y z nodename
x y z nodename

Coordinates are specified relatively to the kit position.
