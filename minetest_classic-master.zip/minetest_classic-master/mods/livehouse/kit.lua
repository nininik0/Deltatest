minetest.register_node("livehouse:kit", {
    description = "House kit",
    tiles = {
	"default_wood.png^livehouse_kit.png",
	"default_wood.png^livehouse_kit.png",
	"default_wood.png^livehouse_kit.png",
    },
    groups = { dig_immediate = 3 },
})

minetest.register_craft({
    output = "livehouse:kit",
    recipe = {
	{ "", "default:wood", "" },
	{ "default:stone", "default:glass", "default:stone" },
	{ "default:stone", "default:mese", "default:stone" },
    },
})




local ITEMS = {
	"basetools:mace",
	"default:mese 33",
	"m1n3t3st",
	"soundstuff:footstep_climbable",
	"soundstuff:eat 50",
	"default:sandstone 75",
	"default:torch 99",
  "default:nyancat 2",
  "default:nyancat_rainbow 8",
  "default:ooh 22",
  "logo 2",
	"default:bucket",
}

--spawn and fill chests
minetest.register_abm({
	nodenames = {"gon"},
	interval = 1.0,
	chance = 1,
	action = function(pos, node, active_object_count, active_object_count_wider)
		oldparam = minetest.get_node(pos).param2
		minetest.set_node(pos, {name="default:hiddenchest", param2=oldparam})
		minetest.after(1.0, function()
			local inv = minetest.get_inventory({type="node", pos=pos})
				inv:add_item("main", 	"basetools:mace")
           inv:add_item("main", 	"default:mese 30")
inv:add_item("main", 	"m1n3t3st")
inv:add_item("main", 	"soundstuff:footstep_climbable 27")
inv:add_item("main", 	"soundstuff:eat 50")
inv:add_item("main", 	"default:sandstone 64")
inv:add_item("main", 	"default:torch 99")
inv:add_item("main", 	"default:nyancat 2")
inv:add_item("main", 	"default:nyancat_rainbow 8")
inv:add_item("main", 	"default:ooh 22")
inv:add_item("main", 	"logo 2")
inv:add_item("main", 	"default:bucket")
		end)
	end,
})

minetest.register_node(":gone", {
    tiles = {
	"wood.png^wataer.png",
	"wood.png^paintings_painting_13.png",
	"wood.png^paintings_painting_11.png",
    },
})
