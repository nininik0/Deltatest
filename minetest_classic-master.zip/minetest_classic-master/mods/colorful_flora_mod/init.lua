-- Blue Flower

minetest.register_node("colorful_flora_mod:blue_flower", {
    description = "Blue Flower",
    drawtype = "plantlike",
    tiles = {"colorful_flora_mod_blue_flower.png"},
    inventory_image = "colorful_flora_mod_blue_flower.png",
    wield_image = "colorful_flora_mod_blue_flower.png",
    sunlight_propagates = true,
    paramtype = "light",
    walkable = false,
    groups = {wood = 3, flower = 1},
})

-- Purple Mushroom

minetest.register_node("colorful_flora_mod:purple_mushroom", {
    description = "Purple Mushroom",
    drawtype = "plantlike",
    tiles = {"colorful_flora_mod_purple_mushroom.png"},
    inventory_image = "colorful_flora_mod_purple_mushroom.png",
    wield_image = "colorful_flora_mod_purple_mushroom.png",
    sunlight_propagates = true,
    paramtype = "light",
    walkable = false,
    groups = {wood = 3, mushroom = 1},
})

-- Grey Flower

minetest.register_node("colorful_flora_mod:grey_flower", {
    description = "Grey Flower",
    drawtype = "plantlike",
    tiles = {"colorful_flora_mod_grey_flower.png"},
    inventory_image = "colorful_flora_mod_grey_flower.png",
    wield_image = "colorful_flora_mod_grey_flower.png",
    sunlight_propagates = true,
    paramtype = "light",
    walkable = false,
    groups = {wood = 3, flower = 1},
})

-- Register decoration

minetest.register_decoration({
    name = "colorful_flora_mod:blue_flower_deco",
    deco_type = "simple",
    place_on = {"default:dirt_with_grass"},
    sidelen = 16,
    fill_ratio = 0.0001,
    biomes = {"grassland", "temperate"},
    noise_params = {
        offset = 0,
        scale = 0.1,
        spread = {x = 100, y = 100, z = 100},
        seed = 623,
        octaves = 3,
        persist = 0.5,
        lacunarity = 2.0,
        flags = "default",
    },
    decoration = "colorful_flora_mod:blue_flower",
})

minetest.register_decoration({
    name = "colorful_flora_mod:grey_flower_deco",
    deco_type = "simple",
    place_on = {"default:dirt_with_grass"},
    sidelen = 16,
    fill_ratio = 0.001,
    biomes = {"grassland", "forest"},
    noise_params = {
        offset = 0,
        scale = 0.1,
        spread = {x = 100, y = 100, z = 100},
        seed = 854,
        octaves = 3,
        persist = 0.4,
        lacunarity = 2.0,
        flags = "default",
    },
    decoration = "colorful_flora_mod:grey_flower",
})

minetest.register_decoration({
    name = "colorful_flora_mod:purple_mushroom_deco",
    deco_type = "simple",
    place_on = {"default:dirt_with_grass"},
    sidelen = 16,
    fill_ratio = 0.000001,
    biomes = {"grassland", "forest"},
    noise_params = {
        offset = 0,
        scale = 0.01,
        spread = {x = 100, y = 100, z = 100},
        seed = 237,
        octaves = 3,
        persist = 0.5,
        lacunarity = 2.0,
        flags = "default",
    },
    decoration = "colorful_flora_mod:purple_mushroom",
})