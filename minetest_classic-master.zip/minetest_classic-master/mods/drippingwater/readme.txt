Dripping Water Mod
by kddekadenz


Installing instructions:

	1. Copy the drippingwater mod folder into games/gamemode/mods

	2. Start game and enjoy :)


Manual:

-> drops are generated rarely under crumbly nodes (dirt,grass,sandstone)
-> they are generated under cloudstone, too
-> they will stay some time at the generated block and than they fall down
-> when they collide with the ground, a sounf is played and they are destroyed


License:

code, textures & sounds: CC0


Changelog:

16.04.2012 - first release
