local craftguide, datas = {}, {}

-- Modified `get_items` to filter out uncraftable items
function craftguide:get_items(filter, player_name)
	local items_list = {}
	for name, def in pairs(minetest.registered_items) do
		local recipes = minetest.get_all_craft_recipes(name)
		if recipes and not def.groups.not_in_creative_inventory and def.description and def.description ~= "" then
			if not filter or name:find(filter, 1, true) or def.description:lower():find(filter, 1, true) then
				items_list[#items_list + 1] = name
			end
		end
	end
	datas[player_name].size = #items_list
	table.sort(items_list)
	return items_list
end

-- Modified `get_formspec` to always display recipes in a 3x3 grid
function craftguide:get_formspec(stack, pagenum, item, recipe_num, filter, player_name)
	local inv_size = datas[player_name].size
	local npp = 24  -- Number of items per page
	local pagemax = math.ceil(inv_size / npp)  -- Calculate total number of pages

	-- Ensure page number is within valid range
	if pagenum > pagemax then pagenum = 1
	elseif pagenum < 1 then pagenum = pagemax end

	local formspec = "size[8,8]" ..
		"button[0,0;1,1;prev;<]" ..
		"button[7,0;1,1;next;>]" ..
		"field[0.3,0.3;3,1;filter;;" .. minetest.formspec_escape(filter) .. "]" ..
		"button[3,0.25;1,0.5;search;Search]" ..
		"button[4,0.25;1,0.5;clear;Clear]" ..
		"label[6.2,0.25;Page "..pagenum.."/"..pagemax.."]"

	-- Render the items in a consistent 3x3 grid
	local i = 0
	for _, name in ipairs(self:get_items(filter, player_name)) do
		if i >= (pagenum - 1) * npp and i < pagenum * npp then
			local x = i % 8
			local y = math.floor(i / 8) % 3 + 1
			formspec = formspec .. "item_image_button[" .. x .. "," .. y .. ";1,1;" .. name .. ";" .. name .. ";]"
		end
		i = i + 1
	end

	-- Display a valid recipe in a 3x3 grid, if applicable
	if item and minetest.registered_items[item] then
		local recipes = minetest.get_all_craft_recipes(item)
		if recipes and #recipes > 0 then
			if recipe_num > #recipes then recipe_num = 1 end
			local recipe = recipes[recipe_num]
			local width = 3

			for i, v in ipairs(recipe.items) do
				local x = (i - 1) % width + 4
				local y = math.floor((i - 1) / width + 5)
				formspec = formspec .. "item_image_button[" .. x .. "," .. y .. ";1,1;" .. v .. ";" .. v .. ";]"
			end

			formspec = formspec .. "item_image_button[7,5;1,1;" .. recipe.output .. ";" .. recipe.output .. ";]" ..
			           "label[6,5.8;Recipe " .. recipe_num .. " / " .. #recipes .. "]"
		else
			formspec = formspec .. "label[2.5,6;No Crafting Recipe Found]"
		end
	end

	stack:set_metadata(formspec)
	datas[player_name].formspec = stack:get_metadata()
	minetest.show_formspec(player_name, "crafting_guide:guide", formspec)
end

minetest.register_on_player_receive_fields(function(player, formname, fields)
	if formname ~= "crafting_guide:guide" then return end
	local player_name = player:get_player_name()
	local stack = player:get_wielded_item()
	local formspec = datas[player_name].formspec
	local filter = formspec:match("filter;;(.-)%]") or ""
	local pagenum = tonumber(formspec:match("Page (%d+)/")) or 1

	if fields.clear then
		craftguide:get_formspec(stack, 1, nil, 1, "", player_name)
	elseif fields.search then
		craftguide:get_formspec(stack, 1, nil, 1, fields.filter:lower(), player_name)
	elseif fields.prev then
		craftguide:get_formspec(stack, pagenum - 1, nil, 1, filter, player_name)
	elseif fields.next then
		craftguide:get_formspec(stack, pagenum + 1, nil, 1, filter, player_name)
	else
		for item in pairs(fields) do
			if minetest.get_craft_recipe(item).items then
				craftguide:get_formspec(stack, pagenum, item, 1, filter, player_name)
			end
		end
	end
end)

minetest.register_on_player_receive_fields(function(player, formname, fields)
	if formname ~= "crafting_guide:guide" then return end
	local player_name = player:get_player_name()
	local stack = player:get_wielded_item()
	local formspec = datas[player_name].formspec
	local filter = formspec:match("field%[0.3,0.32;2.6,1;filter;;([^;]*)%]") or ""
	local pagenum = tonumber(formspec:match("#FFFF00,(%d+)")) or 1

	if fields.clear then
		craftguide:get_items(nil, player_name)
		craftguide:get_formspec(stack, 1, nil, 1, "", player_name)

	elseif fields.alternate then
		local item = formspec:match("item_image_button%[[^%]]+%]%[(.-)%]")
		local recipe_num = tonumber(formspec:match("Recipe%s(%d+)")) or 1
		recipe_num = recipe_num + 1
		craftguide:get_formspec(stack, pagenum, item, recipe_num, filter, player_name)

	elseif fields.search then
		local lowstr = fields.filter:lower()
		craftguide:get_items(lowstr, player_name)
		craftguide:get_formspec(stack, 1, nil, 1, lowstr, player_name)

	elseif fields.prev or fields.next then
		if fields.prev then pagenum = pagenum - 1 else pagenum = pagenum + 1 end
		craftguide:get_formspec(stack, pagenum, nil, 1, filter, player_name)

	else
		for field_name in pairs(fields) do
			if minetest.registered_items[field_name] then
				local recipes = minetest.get_all_craft_recipes(field_name)
				if recipes then
					craftguide:get_formspec(stack, pagenum, field_name, 1, filter, player_name)
				end
				break
			end
		end
	end
end)

minetest.register_craftitem("crafting_guide:guide", {
	description = "Crafting Guide",
	inventory_image = "booksus.png",
	stack_max = 1,
	on_use = function(itemstack, user)
		local player_name = user:get_player_name()
		datas[player_name] = {}
		craftguide:get_items(nil, player_name)
		craftguide:get_formspec(itemstack, 1, nil, 1, "", player_name)
	end
})