
local craftguide, datas = {}, {}

-- Modified `get_items` to filter out uncraftable items
function craftguide:get_items(filter, player_name)
	local items_list = {}
	for name, def in pairs(minetest.registered_items) do
		local recipes = minetest.get_all_craft_recipes(name)
		if recipes and not def.groups.not_in_creative_inventory and def.description and def.description ~= "" then
			if not filter or name:find(filter, 1, true) or def.description:lower():find(filter, 1, true) then
				items_list[#items_list + 1] = name
			end
		end
	end
	datas[player_name].size = #items_list
	table.sort(items_list)
	return items_list
end

-- Modified `get_formspec` to always display recipes in a 3x3 grid
function craftguide:get_formspec(stack, pagenum, item, recipe_num, filter, player_name)
	local inv_size = datas[player_name].size
	local npp = 24  -- Number of items per page (8 x 3 grid)
	local pagemax = math.ceil(inv_size / npp)

	-- Ensure valid page number wrapping
	if pagenum > pagemax then pagenum = 1
	elseif pagenum < 1 then pagenum = pagemax end

	local formspec = "size[8,8]" ..
		"button[0,0;1,1;prev;<]" ..
		"button[7,0;1,1;next;>]" ..
		"field[0.3,0.3;3,1;filter;;" .. minetest.formspec_escape(filter) .. "]" ..
		"button[3,0.25;1,0.5;search;Search]" ..
		"button[4,0.25;1,0.5;clear;Clear]" ..
		"label[6.2,0.25;Page "..pagenum.."/"..pagemax.."]"

	local start_index = (pagenum - 1) * npp + 1
	local end_index = math.min(pagenum * npp, inv_size)
	
	local items = self:get_items(filter, player_name)
	for i = start_index, end_index do
		local name = items[i]
		if name then
			local x = (i - start_index) % 8
			local y = math.floor((i - start_index) / 8) + 1
			formspec = formspec .. "item_image_button[" .. x .. "," .. y .. ";1,1;" .. name .. ";" .. name .. ";]"
		end
	end

	-- Display crafting recipes in a proper 3x3 grid
	if item and minetest.registered_items[item] then
		local recipes = minetest.get_all_craft_recipes(item)
		if recipes and #recipes > 0 then
			if recipe_num > #recipes then recipe_num = 1 end
			local recipe = recipes[recipe_num]
			local width = recipe.width or 3
			if width == 0 then width = 3 end  -- Ensure recipes default to 3x3 grid

			for i = 1, 9 do
				local x = (i - 1) % 3 + 4
				local y = math.floor((i - 1) / 3 + 5)
				local v = recipe.items[i] or ""
				formspec = formspec .. "item_image_button[" .. x .. "," .. y .. ";1,1;" .. v .. ";" .. v .. ";]"
			end

			formspec = formspec .. "item_image_button[7,5;1,1;" .. recipe.output .. ";" .. recipe.output .. ";]" ..
			           "label[6,5.8;Recipe " .. recipe_num .. " / " .. #recipes .. "]"
		else
			formspec = formspec .. "label[2.5,6;No Crafting Recipe Found]"
		end
	end

	stack:set_metadata(formspec)
	datas[player_name].formspec = stack:get_metadata()
	minetest.show_formspec(player_name, "crafting_guide:guide", formspec)
end

function craftguide:get_items(filter, player_name)
	local items_list = {}
	for name, def in pairs(minetest.registered_items) do
		if not (def.groups.not_in_creative_inventory == 1) and
		   minetest.get_all_craft_recipes(name) and
		   def.description and def.description ~= "" and
		   (not filter or name:find(filter, 1, true) or def.description:lower():find(filter, 1, true)) then
			items_list[#items_list + 1] = name
		end
	end
	datas[player_name].size = #items_list
	table.sort(items_list)
	return items_list
end

minetest.register_on_player_receive_fields(function(player, formname, fields)
	if formname ~= "crafting_guide:guide" then return end
	local player_name = player:get_player_name()
	local stack = player:get_wielded_item()
	local formspec = datas[player_name].formspec
	local filter = formspec:match("filter;;(.-)%]") or ""
	local pagenum = tonumber(formspec:match("Page (%d+)/")) or 1

	if fields.clear then
		craftguide:get_formspec(stack, 1, nil, 1, "", player_name)
	elseif fields.search then
		craftguide:get_formspec(stack, 1, nil, 1, fields.filter:lower(), player_name)
	elseif fields.prev then
		craftguide:get_formspec(stack, pagenum - 1, nil, 1, filter, player_name)
	elseif fields.next then
		craftguide:get_formspec(stack, pagenum + 1, nil, 1, filter, player_name)
	else
		for item in pairs(fields) do
			if minetest.registered_items[item] then
				craftguide:get_formspec(stack, pagenum, item, 1, filter, player_name)
			end
		end
	end
end)

minetest.register_craftitem("crafting_guide:guide", {
	description = "Crafting Guide",
	inventory_image = "booksus.png",
	stack_max = 1,
	on_use = function(itemstack, user)
		local player_name = user:get_player_name()
		datas[player_name] = {}
		craftguide:get_items(nil, player_name)
		craftguide:get_formspec(itemstack, 1, nil, 1, "", player_name)
	end
})