
local path = minetest.get_modpath("soundstuff") .. "/"
dofile(path .. "sound_event_items.lua")
dofile(path .. "jukebox.lua")


-- Sound settings
local sound_interval = 360 -- 6 minutes in seconds
local sound_timer = 0
local sound_name = "amb" -- Replace with your sound file's name

-- Global step to track time and play sound
minetest.register_globalstep(function(dtime)
    sound_timer = sound_timer + dtime
    if sound_timer >= sound_interval then
        -- Play the sound globally
        minetest.sound_play(sound_name, {
            gain = 0.8,            -- Volume of the sound
            loop = false,          -- Set to true if you want the sound to loop
            max_hear_distance = 50 -- Distance within which the sound can be heard
        })
        sound_timer = 0 -- Reset the timer
    end
end)


minetest.register_craftitem(":soundstuff:cheese", {
    description = "Cheese",
    inventory_image = "cheese.png", -- Replace with your cheese texture
    on_use = minetest.item_eat(4),  -- Heals 4 HP (2 hearts)
})
minetest.register_tool(":default:tool_dipick", {
	description = "cyan pickaxe for bloxks",
	inventory_image = "depixk.png",
	tool_capabilities = {
		full_punch_interval = 0.1,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=0.1, [2]=0.1, [3]=0.1}, uses=20000, maxlevel=3},
       crumbly = {times={[1]= 0.4, [2]=0.2, [3]=0.0}, uses=2000, maxlevel=3},
       choppy = {times={[1]= 0.4, [2]=0.2, [3]=0.0}, uses=2000, maxlevel=3},  
		},
		damage_groups = {fleshy=15},
	},
})