A cleaner, simpler, solution to having an advanced inventory in Minetest.
Originally taken from Minetest Game (with modifications).

Authors of source code
----------------------
Andrew Ward (rubenwardy) <rw@rubenwardy.com> (MIT)
