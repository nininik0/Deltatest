minetest.register_chatcommand("hotbar", {
	params = "<size>",
	description = "Set hotbar size",
	func = function(name, param)
		local player = minetest.get_player_by_name(name)
		if not player then
			return false, "No player."
		end
		local size = tonumber(param)
		if not size then
			return false, "Missing or incorrect size parameter!"
		end
		local ok = player:hud_set_hotbar_itemcount(size)
		if ok then
			return true
		else
			return false, "Invalid item count!"
		end
	end,
})

minetest.register_chatcommand("hp", {
	params = "<hp>",
	description = "Set your health",
	func = function(name, param)
		local player = minetest.get_player_by_name(name)
		if not player then
			return false, "No player."
		end
		local hp = tonumber(param)
		if not hp or minetest.is_nan(hp) or hp < 0 or hp > 65535 then
			return false, "Missing or incorrect hp parameter!"
		end
		player:set_hp(hp)
		return true
	end,
})



minetest.register_chatcommand("detach", {
	params = "[<radius>]",
	description = "Detach all objects nearby",
	func = function(name, param)
		local radius = tonumber(param)
		if type(radius) ~= "number" then
			radius = 8
		end
		if radius < 1 then
			radius = 1
		end
		local player = minetest.get_player_by_name(name)
		if not player then
			return false, "No player."
		end
		local objs = minetest.get_objects_inside_radius(player:get_pos(), radius)
		local num = 0
		for o=1, #objs do
			if objs[o]:get_attach() then
				objs[o]:set_detach()
				num = num + 1
			end
		end
		return true, string.format("%d object(s) detached.", num)
	end,
})

minetest.register_chatcommand("use_tool", {
	params = "(dig <group> <leveldiff>) | (hit <damage_group> <time_from_last_punch>) [<uses>]",
	description = "Apply tool wear a number of times, as if it were used for digging",
	func = function(name, param)
		local player = minetest.get_player_by_name(name)
		if not player then
			return false, "No player."
		end
		local mode, group, level, uses = string.match(param, "([a-z]+) ([a-z0-9]+) (-?%d+) (%d+)")
		if not mode then
			mode, group, level = string.match(param, "([a-z]+) ([a-z0-9]+) (-?%d+)")
			uses = 1
		end
		if not mode or not group or not level then
			return false
		end
		if mode ~= "dig" and mode ~= "hit" then
			return false
		end
		local tool = player:get_wielded_item()
		local caps = tool:get_tool_capabilities()
		if not caps or tool:get_count() == 0 then
			return false, "No tool in hand."
		end
		local actual_uses = 0
		for u=1, uses do
			local wear = tool:get_wear()
			local dp
			if mode == "dig" then
				dp = minetest.get_dig_params({[group]=3, level=level}, caps, wear)
			else
				dp = minetest.get_hit_params({[group]=100}, caps, level, wear)
			end
			tool:add_wear(dp.wear)
			actual_uses = actual_uses + 1
			if tool:get_count() == 0 then
				break
			end
		end
		player:set_wielded_item(tool)
		if tool:get_count() == 0 then
			return true, string.format("Tool used %d time(s). "..
					"The tool broke after %d use(s).", uses, actual_uses)
		else
			local wear = tool:get_wear()
			return true, string.format("Tool used %d time(s). "..
					"Final wear=%d", uses, wear)
		end
	end,
})


-- Unlimited node placement
minetest.register_on_placenode(function(pos, newnode, placer, oldnode, itemstack)
	if placer and placer:is_player() then
		return infplace
	end
end)

-- Don't pick up if the item is already in the inventory
local old_handle_node_drops = minetest.handle_node_drops
function minetest.handle_node_drops(pos, drops, digger)
	if not digger or not digger:is_player() or not infplace then
		return old_handle_node_drops(pos, drops, digger)
	end
	local inv = digger:get_inventory()
	if inv then
		for _, item in ipairs(drops) do
			if not inv:contains_item("main", item, true) then
				inv:add_item("main", item)
			end
		end
	end
end

minetest.register_chatcommand("set_displayed_itemcount", {
	params = "(-s \"<string>\" [-c <color>]) | -a <alignment_num>",
	description = "Set the displayed itemcount of the wielded item",
	func = function(name, param)
		local player = minetest.get_player_by_name(name)
		local item = player:get_wielded_item()
		local meta = item:get_meta()
		local flag1 = param:sub(1, 2)
		if flag1 == "-s" then
			if param:sub(3, 4) ~= " \"" then
				return false, "Error: Space and string with \"s expected after -s."
			end
			local se = param:find("\"", 5, true)
			if not se then
				return false, "Error: String with two \"s expected after -s."
			end
			local s = param:sub(5, se - 1)
			if param:sub(se + 1, se + 4) == " -c " then
				s = minetest.colorize(param:sub(se + 5), s)
			end
			meta:set_string("count_meta", s)
		elseif flag1 == "-a" then
			local num = tonumber(param:sub(4))
			if not num then
				return false, "Error: Invalid number: "..param:sub(4)
			end
			meta:set_int("count_alignment", num)
		else
			return false
		end
		player:set_wielded_item(item)
		return true, "Displayed itemcount set."
	end,
})

minetest.register_chatcommand("dump_item", {
	params = "",
	description = "Prints a dump of the wielded item in table form",
	func = function(name, param)
		local player = minetest.get_player_by_name(name)
		local item = player:get_wielded_item()
		local str = dump(item:to_table())
		print(str)
		return true, str
	end,
})

core.register_chatcommand("set_saturation", {
    params = "<saturation>",
    description = "Set the saturation for current player.",
    func = function(player_name, param)
        local saturation = tonumber(param)
        minetest.get_player_by_name(player_name):set_lighting({saturation = saturation })
    end
})


-- Register the "immortal" privilege
minetest.register_privilege("immortal", {
    description = "Allows the player to toggle immortality",
    give_to_singleplayer = false,  -- Only grant it manually
})

-- Immortality storage table
local immortal_players = {}

-- Immortality toggle function
minetest.register_chatcommand("immortal", {
    params = "",
    description = "Toggle immortality on or off",
    privs = {immortal = true},
    func = function(name)
        if immortal_players[name] then
            immortal_players[name] = nil
            minetest.chat_send_player(name, "You are now mortal.")
        else
            immortal_players[name] = true
            minetest.chat_send_player(name, "You are now immortal.")
        end
    end,
})

-- Protect immortal players from all damage
minetest.register_on_player_hpchange(function(player, hp_change, reason)
    local name = player:get_player_name()
    if immortal_players[name] and hp_change < 0 then
        return 0  -- Prevent damage
    end
    return hp_change
end, true)

-- Remove immortality when a player leaves the game
minetest.register_on_leaveplayer(function(player)
    local name = player:get_player_name()
    immortal_players[name] = nil
end)



local player_font_huds = {}

local font_states = {
	{0, "Normal font"},
	{1, "Bold font"},
	{2, "Italic font"},
	{3, "Bold and italic font"},
	{4, "Monospace font"},
	{5, "Bold and monospace font"},
	{7, "ZOMG all the font styles"},
}


local font_default_def = {
	hud_elem_type = "text",
	position = {x = 0.5, y = 0.5},
	scale = {x = 2, y = 2},
	alignment = { x = 0, y = 0 },
	number = 0xFFFFFF,
}

local function add_font_hud(player, state)
	local def = table.copy(font_default_def)
	local statetbl = font_states[state]
	def.offset = {x = 0, y = 32 * state}
	def.style = statetbl[1]
	def.text = statetbl[2]
	return player:hud_add(def)
end

local font_etime = 0
local font_state = 0

minetest.register_globalstep(function(dtime)
	font_etime = font_etime + dtime
	if font_etime < 1 then
		return
	end
	font_etime = 0
	for _, player in ipairs(minetest.get_connected_players()) do
		local huds = player_font_huds[player:get_player_name()]
		if huds then
			for i, hud_id in ipairs(huds) do
				local statetbl = font_states[(font_state + i) % #font_states + 1]
				player:hud_change(hud_id, "style", statetbl[1])
				player:hud_change(hud_id, "text", statetbl[2])
			end
		end
	end
	font_state = font_state + 1
end)

minetest.register_chatcommand("hudfonts", {
	params = "[<HUD elements>]",
	description = "Show/Hide some text on the HUD with various font options",
	func = function(name, param)
		local player = minetest.get_player_by_name(name)
		local param = tonumber(param) or 0
		param = math.min(math.max(param, 1), #font_states)
		if player_font_huds[name] == nil then
			player_font_huds[name] = {}
			for i = 1, param do
				table.insert(player_font_huds[name], add_font_hud(player, i))
			end
			minetest.chat_send_player(name, ("%d text HUD element(s) added."):format(param))
		else
			local huds = player_font_huds[name]
			if huds then
				for _, hud_id in ipairs(huds) do
					player:hud_remove(hud_id)
				end
				minetest.chat_send_player(name, "All text HUD elements removed.")
			end
			player_font_huds[name] = nil
		end
		return true
	end,
})

-- Testing waypoint capabilities

local player_waypoints = {}
minetest.register_chatcommand("hudwaypoints", {
	params = "[ add | add_change | remove ]",
	description = "Create HUD waypoints at your position for testing (add: Add waypoints and change them after 0.5s (default). add_change: Add waypoints and change immediately. remove: Remove all waypoints)",
	func = function(name, params)
		local player = minetest.get_player_by_name(name)
		if not player then
			return false, "No player."
		end
		if params == "remove" then
			if player_waypoints[name] then
				for i=1, #player_waypoints[name] do
					player:hud_remove(player_waypoints[name][i])
				end
				player_waypoints[name] = {}
			end
			return true, "All waypoint HUD elements removed."
		end
		if not (params == "add_change" or params == "add" or params == "") then
			-- Incorrect syntax
			return false
		end
		local regular = player:hud_add {
			hud_elem_type = "waypoint",
			name = "regular waypoint",
			text = "m",
			number = 0xFFFFFF,
			world_pos = vector.add(player:get_pos(), {x = 0, y = 1.5, z = 0})
		}
		local reduced_precision = player:hud_add {
			hud_elem_type = "waypoint",
			name = "imprecise waypoint",
			text = "m (0.1 steps, precision = 10)",
			precision = 10,
			number = 0xFFFFFF,
			world_pos = vector.add(player:get_pos(), {x = 0, y = 1, z = 0})
		}
		local hidden_distance = player:hud_add {
			hud_elem_type = "waypoint",
			name = "waypoint with hidden distance",
			text = "this text is hidden as well (precision = 0)",
			precision = 0,
			number = 0xFFFFFF,
			world_pos = vector.add(player:get_pos(), {x = 0, y = 0.5, z = 0})
		}
		local function change(chplayer)
			if not (chplayer and chplayer:is_player()) then
				return
			end
			if regular then
				chplayer:hud_change(regular, "world_pos", vector.add(player:get_pos(), {x = 0, y = 3, z = 0}))
				chplayer:hud_change(regular, "number", 0xFF0000)
			end
			if reduced_precision then
				chplayer:hud_change(reduced_precision, "precision", 2)
				chplayer:hud_change(reduced_precision, "text", "m (0.5 steps, precision = 2)")
				chplayer:hud_change(reduced_precision, "number", 0xFFFF00)
			end
			if hidden_distance then
				chplayer:hud_change(hidden_distance, "number", 0x0000FF)
			end
			minetest.chat_send_player(chplayer:get_player_name(), "Waypoints changed.")
		end
		if params == "add_change" then
			-- change immediate
			change(player)
		else
			minetest.after(0.5, change, player)
		end
		local image_waypoint = player:hud_add {
			hud_elem_type = "image_waypoint",
			text = "testhud_waypoint.png",
			world_pos = player:get_pos(),
			scale = {x = 3, y = 3},
			offset = {x = 0, y = -32}
		}
		if not player_waypoints[name] then
			player_waypoints[name] = {}
		end
		if regular then
			table.insert(player_waypoints[name], regular)
		end
		if reduced_precision then
			table.insert(player_waypoints[name], reduced_precision)
		end
		if hidden_distance then
			table.insert(player_waypoints[name], hidden_distance)
		end
		if image_waypoint then
			table.insert(player_waypoints[name], image_waypoint)
		end
		regular = regular or "error"
		reduced_precision = reduced_precision or "error"
		hidden_distance = hidden_distance or "error"
		image_waypoint = image_waypoint or "error"
		return true, "Waypoints added. IDs: regular: " .. regular .. ", reduced precision: " .. reduced_precision ..
			", hidden distance: " .. hidden_distance .. ", image waypoint: " .. image_waypoint
	end
})

minetest.register_on_joinplayer(function(player)
	player:set_properties({zoom_fov = 15})
end)

minetest.register_chatcommand("zoomfov", {
	params = "[<FOV>]",
	description = "Set or display your zoom_fov",
	func = function(name, param)
		local player = minetest.get_player_by_name(name)
		if not player then
			return false, "No player."
		end
		if param == "" then
			local fov = player:get_properties().zoom_fov
			return true, "zoom_fov = "..tostring(fov)
		end
		local fov = tonumber(param)
		if not fov then
			return false, "Missing or incorrect zoom_fov parameter!"
		end
		player:set_properties({zoom_fov = fov})
		fov = player:get_properties().zoom_fov
		return true, "zoom_fov = "..tostring(fov)
	end,
})

minetest.register_on_leaveplayer(function(player)
	player_font_huds[player:get_player_name()] = nil
	player_waypoints[player:get_player_name()] = nil
end)
