dofile(minetest.get_modpath("default").."/bucket.lua")

--[[
	Minetest Classic
	Copyright (c) 2022 sfan5 <sfan5@live.de>

	SPDX-License-Identifier: LGPL-2.1-or-later
--]]

default = {}

-- Original references:
-- nodes https://github.com/minetest/minetest/blob/stable-0.3/src/content_mapnode.cpp#L104
-- crafting https://github.com/minetest/minetest/blob/stable-0.3/src/content_craft.cpp#L30
-- items https://github.com/minetest/minetest/blob/stable-0.3/src/content_inventory.cpp
-- tools https://github.com/minetest/minetest/blob/stable-0.3/src/inventory.h#L308
-- meta/formspec https://github.com/minetest/minetest/blob/stable-0.3/src/content_nodemeta.cpp
-- selection boxes https://github.com/minetest/minetest/blob/stable-0.3/src/game.cpp#L348
-- interact handlers https://github.com/minetest/minetest/blob/stable-0.3/src/server.cpp#L2238
-- LBM https://github.com/minetest/minetest/blob/stable-0.3/src/environment.cpp#L622

-- Node compatibility list that still exists in the engine today:
-- https://github.com/minetest/minetest/blob/stable-5/src/content_mapnode.cpp#L123

-- v v v v v v v v v
-- Lots of old content (including playable releases) can be found here:
-- http://packages.8dromeda.net/minetest/
-- ^ ^ ^ ^ ^ ^ ^ ^ ^

-- TODO set is_ground_content sanely or exactly as in orginal?

-- TODOs:
-- come up with some sane item groups to use
-- generate failed dungeons in water (like an U)
-- do stone deserts appear naturally?
-- 'footprints'
-- sound ideas: furnace, eating
-- falling sand/gravel
-- investigate long vertical shafts (mgv6 fail?)

-- long-term TODOs?:
-- consider adding unfinished features like firefly spawn & standing signs
-- texture animations for some
-- translation support
-- protection support
-- 3d model signs and torches
-- maybe 3d model mobs

--
-- Modernize setting
--

default.modernize = {
	-- 'waving' set on suitable nodes
	node_waving = false,
	-- glass uses glasslike drawtype instead of allfaces
	glasslike = false,
	-- Breathbar/drowning is enabled
	drowning = false,
	-- Lava is not renewable
	lava_non_renewable = false,
	-- Allows the engine shadowmapping to be used
	allow_shadows = false,
	-- Allows the minimap to be used
	allow_minimap = false,
	-- Allows the player to zoom
	allow_zoom = false,
	-- Keeps the (new) item entity from the engine instead of emulating the old one
	new_item_entity = false,
	-- Don't delete Oerkki if the player gets too close
	disable_oerkki_delete = false,
	-- Replace some textures that look out of place/unfinished
	fix_textures = false,
	-- Enable sounds
	sounds = false,
	-- Add a wieldhand texture instead of having it invisible
	wieldhand = true,
	-- Allows PvP
	pvp = false,

	-- TODO disable_rightclick_drop, new_skybox, allow_drop, glasslike_framed
}
local modernize_default = "node_waving,glasslike,drowning,allow_shadows,new_item_entity,disable_oerkki_delete,fix_textures,sounds,wieldhand"

do
	local warned = {}
	setmetatable(default.modernize, {
		__index = function(self, key)
			if not warned[key] then
				minetest.log("warning",
					("Undeclared modernize flag accessed: %q"):format(key))
				warned[key] = true
			end
		end,
	})
end

local function parse_flagstr(dest, s)
	local flags = string.split(s, ",", false)
	for _, flag in ipairs(flags) do
		flag = flag:gsub("^%s*", ""):gsub("%s*$", "")
		-- "node" also begins with "no" hence the extra check
		if flag:sub(1, 2) == "no" and rawget(dest, flag:sub(3)) ~= nil then
			dest[flag:sub(3)] = false
		else
			dest[flag] = true
		end
	end
end

do
	local s = minetest.settings:get("modernize")
	if (s or "") == "" then
		s = modernize_default
	end
	parse_flagstr(default.modernize, s)
	local n, ntot = 0, 0
	for _, value in pairs(default.modernize) do
		n = n + (value and 1 or 0)
		ntot = ntot + 1
	end
	print(("Minetest Classic: %d/%d modernization flags enabled"):format(n, ntot))
end

--
-- Misc code
--

-- polyfill: math.round (5.5)
if math.round == nil then
	math.round = function(x)
		if x >= 0 then
			return math.floor(x + 0.5)
		end
		return math.ceil(x - 0.5)
	end
end

-- polyfill: vector.zero (5.5)
if vector.zero == nil then
	vector.zero = function()
		return vector.new(0, 0, 0)
	end
end

-- polyfill: vector.combine (5.6)
if vector.combine == nil then
	vector.combine = function(a, b, func)
		return vector.new(func(a.x, b.x), func(a.y, b.y), func(a.z, b.z))
	end
end

-- returns drop_count, objref
local function item_to_entity(pos, itemstack)
	if itemstack:get_name() == "default:rat" then
		return 1, minetest.add_entity(pos, "default:rat")
	elseif itemstack:get_name() == "default:firefly" then
		return 1, minetest.add_entity(pos, "default:firefly")
	end
	return itemstack:get_count(), minetest.add_item(pos, itemstack)
end

local old_item_place = minetest.item_place
minetest.item_place = function(itemstack, placer, pointed_thing, ...)
	local itemstack, pos = old_item_place(itemstack, placer, pointed_thing, ...)
	-- When rightclicking a node with an item the item is dropped on top
	-- FIXME this might break on_rightclick if we're not careful
	if pos == nil and pointed_thing.type == "node" and
		not minetest.registered_nodes[itemstack:get_name()] then
		pos = vector.new(pointed_thing.above)
		pos.x = pos.x + math.random(-200, 200) / 1000
		pos.z = pos.z + math.random(-200, 200) / 1000
		local drop_count, obj = item_to_entity(pos, itemstack)
		if obj then
			local ret = itemstack
			if not minetest.is_creative_enabled(placer:get_player_name()) then
				ret:take_item(drop_count)
			end
			return ret, nil
		end
	end
	return itemstack, nil
end

minetest.register_on_joinplayer(function(player)
	player:set_properties({
		pointable = default.modernize.pvp,
		nametag_bgcolor = "#00000000",
		zoom_fov = default.modernize.allow_zoom and 15 or 0,
	})
	if not default.modernize.allow_minimap then
		player:hud_set_flags({minimap = false})
	end
	if default.modernize.pvp then
		player:set_armor_groups({fleshy = 75})
	end
	player:set_physics_override({sneak_glitch = true})
	if player.set_lighting and default.modernize.allow_shadows then
		player:set_lighting({shadows = { intensity = 0.33 }})
	end
end)

-- TODO: once supported by the engine this should be migrated to a bulk LBM
minetest.register_lbm({
	label = "Convert to grass",
	name = "default:convert_to_grass",
	nodenames = {"default:dirt"},
	run_at_every_load = true,
	action = function(pos, node, dtime_s)
		if dtime_s == nil then
			return -- (since 5.7.0)
		end
		-- This originally operated on blocks so the above node for the topmost node
		-- would not be available, meaning the conversion could never happen for it
		if pos.y % 16 == 15 then
			return
		end
		if dtime_s > 300 then
			local p1 = vector.offset(pos, 0, 1, 0)
			local above = minetest.get_node(p1)
			local has_air = above.name == "air" or minetest.get_item_group(above.name, "air_equivalent") > 0
			if has_air and minetest.get_node_light(p1, 0.5) >= 13 then
				node.name = "default:dirt_with_grass"
				minetest.swap_node(pos, node)
			end
		end
	end,
})

minetest.register_on_newplayer(function(player)
	if not core.settings:get_bool("give_initial_stuff") then
		return
	end
	if minetest.is_creative_enabled(player:get_player_name()) then
		return
	end
	local inv = player:get_inventory()
	local items = {
		"default:pick_steel",
		"default:torch 99",
		"default:axe_steel",
		"default:shovel_steel",
		"default:cobble 99",
	}
	for _, item in ipairs(items) do
		inv:add_item("main", item)
	end
end)

--
-- Skybox
--

local light_decode_table = {8, 11, 14, 18, 22, 29, 37, 47, 60, 76, 97, 123, 157, 200, 255}
local function time_to_daynight_ratio(tod)
	local daylength, nightlength, daytimelength = 16, 6, 8
	local t = (tod % 24000) / math.floor(24000 / daylength)
	if t < nightlength / 2 or t >= daylength - nightlength / 2 then
		return 350
	elseif t >= daylength / 2 - daytimelength / 2 and t < daylength / 2 + daytimelength / 2 then
		return 1000
	else
		return 750
	end
end

default.set_skybox = function(player, brightness)
	local t = "_night"
	if brightness >= 0.5 then
		t = ""
	elseif brightness >= 0.2 then
		t = "_dawn"
	end
	local c = math.floor(brightness * 255)
	player:set_sky({
		type = "skybox",
		base_color = string.format("#%02x%02x%02x", c, c, c), -- fog
		textures = {
			"skybox2" .. t .. ".png",
			"skybox3" .. t .. ".png",
			"skybox1" .. t .. ".png",
			"skybox1" .. t .. ".png",
			"skybox1" .. t .. ".png",
			"skybox1" .. t .. ".png"
		},
	})
end

local last_brightness = -1

minetest.register_globalstep(function()
	local tod_f = minetest.get_timeofday()
	local ratio = time_to_daynight_ratio(tod_f * 24000)
	local index = math.floor(ratio * #light_decode_table / 1000)
	index = math.min(index, #light_decode_table - 1)
	local brightness = light_decode_table[index + 1] / 255

	if math.abs(last_brightness - brightness) < 0.03 then
		return
	end
	last_brightness = brightness
	for _, player in ipairs(minetest.get_connected_players()) do
		default.set_skybox(player, brightness)
	end
end)

minetest.register_on_joinplayer(function(player)
	if last_brightness ~= nil then
		default.set_skybox(player, last_brightness)
	end
	-- keep sun and moon but set invisible texture, needed for shadow support
	player:set_sun({ texture = "sun.png", sunrise_visible = false })
	player:set_moon({ texture = "moon.png" })
	player:set_stars({ visible = false })
	player:set_clouds({
		color = "#00bb00",
		speed = {x=-2, z=2},
	})
end)

--
-- Dig groups
--

-- equivalent to setDirtLikeDiggingProperties, uses "dirt" group
-- starting at level 1
default.dirt_levels = { 0.75, 1.0, 1.75 }

-- equivalent to setStoneLikeDiggingProperties, uses "stone" group
default.stone_levels = { 0.5, 0.8, 0.9, 1.0, 1.5, 3.0, 5.0 }

-- equivalent to setWoodLikeDiggingProperties, uses "wood" group
default.wood_levels = { 0.1, 0.15, 0.25, 0.5, 0.75, 1.0 }

-- dig_hand = 1 <=> 0.5s
-- dig_hand = 2 <=> instant

-- dig_mese = 1 <=> instant (only diggable with mese pick)

-- TODO custom uses calculation wear = 65535 / uses * toughness

--
-- Sounds
--

local function extend(parent, tbl)
	assert(type(parent) == type(tbl) and type(tbl) == "table")
	assert(parent ~= tbl)
	return setmetatable(tbl, { __index = parent })
end

--[[
Quick history lesson:
* footstep, dig, dug and place sounds were added in 0.4.dev-20120326
  The dig sound got a default of "__group" that automatically picks a
  sound named `default_dig_<groupname>`, this feature still exists today (yuck)
* the place sound was un-hardcoded in 0.4.6
* swimming and tool break sounds were added to Minetest Game in 0.4.15
* environmental sound (flowing water) was added to MTG in 5.1.0

Observations:
* The first win32 build that has working sound for me is 0.4.6, though
  earlier releases can be fixed by copying over wrap_oal.dll from newer ones
* Some of the sounds defined in 0.4.0 are missing and were only added later,
  e.g. default_break_glass in 0.4.4
* A big sound redesign in MTG happened in 0.4.8

To give a nostalgic feeling(*) the sounds here are taken from 0.4.7 with select
ones from newer versions. Dig sounds are mapped according to what the __group
automatism would choose for most of the nodes. Environment sounds are not implemented.
(*): The sounds are pretty bad so this might be revisited
--]]

default.node_sound = {}

do
	local warned = {}
	setmetatable(default.node_sound, {
		__index = function(self, key)
			if not warned[key] then
				minetest.log("warning",
					("Undeclared key in default.node_sound accessed: %q"):format(key))
				warned[key] = true
			end
		end,
	})
end

default.node_sound.default = {
	dig   = {name = ""}, -- disable automatic group-based handling
	dug   = {name = "default_dug_node",   gain = 1.0},
	place = {name = "default_place_node", gain = 0.5},
}

default.node_sound.stone = extend(default.node_sound.default, {
	footstep = {name = "default_hard_footstep", gain = 0.2},
	dig      = {name = "default_dig_cracky",    gain = 1.0},
})

default.node_sound.dirt = extend(default.node_sound.default, {
	footstep = {name = "default_dirt_footstep", gain = 1.0}, -- (from 0.4.8)
	dig      = {name = "default_dig_crumbly",   gain = 1.0},
})

default.node_sound.grass = extend(default.node_sound.dirt, {
	footstep = {name = "default_grass_footstep", gain = 0.4},
})

default.node_sound.sand = extend(default.node_sound.default, {
	footstep = {name = "default_grass_footstep", gain = 0.25},
	dig      = {name = "default_dig_crumbly",    gain = 1.0},
	dug      = {name = ""},
})

default.node_sound.gravel = extend(default.node_sound.dirt, {
	footstep = {name = "default_gravel_footstep", gain = 0.45},
})

default.node_sound.wood = extend(default.node_sound.default, {
	footstep = {name = "default_hard_footstep", gain = 0.3},
	dig      = {name = "default_dig_choppy",    gain = 1.0},
})

default.node_sound.leaves = extend(default.node_sound.default, {
	footstep = {name = "default_grass_footstep", gain = 0.25},
	dig      = {name = "default_dig_crumbly",    gain = 0.4},
	dug      = {name = ""},
})

default.node_sound.glass = extend(default.node_sound.default, {
	footstep = {name = "default_hard_footstep",  gain = 0.25},
	dig      = {name = "default_dig_cracky",     gain = 1.0},
	dug      = {name = "default_break_glass",    gain = 1.0},
})

default.node_sound.water = extend(default.node_sound.default, {
	footstep = {name = "default_water_footstep", gain = 0.2}, -- (from 0.4.15)
})

default.node_sound.other = {
	dig = {name = "default_dig_dig_immediate", gain = 1.0},
}

default.tool_sound = {
	breaks = {name = "default_tool_breaks", gain = 1.0}, -- (from 0.4.15)
}

if not default.modernize.sounds then
	for k, _ in pairs(default.node_sound) do
		default.node_sound[k] = {}
	end
	default.tool_sound = {}
end

--
-- Nodes
--

minetest.register_node("default:stone", {
	description = "Stone",
	tiles = { "stone.png" },
	groups = { stone = 4 },
	drop = "default:cobble",
	sounds = default.node_sound.stone,
})

minetest.register_node("default:dirt_with_grass", {
	description = "Dirt With Grass",
	tiles = { "grass.png", "mud.png", "grass_side.png" },
	groups = { dirt = 2 },
	drop = "default:dirt",
	sounds = default.node_sound.grass,
})

minetest.register_node("default:dirt_with_grass_footsteps", {
	description = "Dirt With Grass and Footsteps",
	tiles = { "grass_footsteps.png", "mud.png", "grass_side.png" },
	-- TODO find better texture here?
	groups = { dirt = 2, not_in_creative_inventory = 1 },
	drop = "default:dirt",
	sounds = default.node_sound.grass,
})

minetest.register_node("default:dirt", {
	description = "Dirt",
	tiles = { "mud.png" },
	groups = { dirt = 2 },
	sounds = default.node_sound.dirt,
})

minetest.register_node("default:sand", {
	description = "Sand",
	tiles = { "sand.png" },
	groups = { dirt = 2 },
	sounds = default.node_sound.sand,
})

minetest.register_node("default:gravel", {
	description = "Gravel",
	tiles = { "gravel.png" },
	groups = { dirt = 3 },
	sounds = default.node_sound.gravel,
})

minetest.register_node("default:sandstone", {
	description = "Sandstone",
	tiles = { "sandstone.png" },
	groups = { dirt = 2 },
	drop = "default:sand",
	sounds = default.node_sound.stone,
})

minetest.register_node("default:clay", {
	description = "Clay",
	tiles = { "clay.png" },
	groups = { dirt = 2 },
	drop = "default:lump_of_clay 4",
	sounds = default.node_sound.dirt,
})

minetest.register_node("default:brick", {
	description = "Brick",
	tiles = { "brick.png" },
	groups = { stone = 4 },
	drop = "default:clay_brick 4",
	sounds = default.node_sound.stone,
})

minetest.register_node("default:tree", {
	description = "Tree Trunk",
	tiles = { "tree_top.png", "tree_top.png", "tree.png" },
	groups = { wood = 6 },
	is_ground_content = false,
	sounds = default.node_sound.wood,
})

minetest.register_node("default:jungletree", {
	description = "Jungle Tree Trunk",
	tiles = { "jungletree_top.png", "jungletree_top.png", "jungletree.png" },
	groups = { wood = 6 },
	is_ground_content = false,
	sounds = default.node_sound.wood,
})

minetest.register_node("default:junglegrass", {
	description = "Jungle Grass",
	drawtype = "plantlike",
	visual_scale = 2, -- TODO need on Y only
	tiles = {"junglegrass.png"},
	inventory_image = "junglegrass.png",
	wield_image = "junglegrass.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	groups = { wood = 1 },
	sounds = default.node_sound.leaves,
})

minetest.register_node("default:leaves", {
	description = "Leaves",
	tiles = { "leaves.png" },
	special_tiles = { "leaves.png" },
	groups = { wood = 2 },
	drawtype = "allfaces_optional",
	waving = default.modernize.node_waving and 1 or nil,
	paramtype = "light",
	is_ground_content = false,
	drop = {
		items = {
			{ items = {"default:sapling"}, rarity = 20 },
			{ items = {"default:leaves"} }
		}
	},
	sounds = default.node_sound.leaves,
})

minetest.register_node("default:cactus", {
	description = "Cactus",
	tiles = { "cactus_top.png", "cactus_top.png", "cactus_side.png" },
	groups = { wood = 5 },
	sounds = default.node_sound.wood,
})

minetest.register_node("default:papyrus", {
	description = "Papyrus",
	drawtype = "plantlike",
	tiles = {"papyrus.png"},
	inventory_image = "papyrus.png",
	wield_image = "papyrus.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	groups = { wood = 3 },
	sounds = default.node_sound.leaves,
})

minetest.register_node("default:bookshelf", {
	description = "Bookshelf",
	tiles = { "wood.png", "wood.png", "bookshelf.png" },
	groups = { wood = 5 },
	sounds = default.node_sound.wood,
})

minetest.register_node("default:glass", {
	description = "Glass",
	drawtype = default.modernize.glasslike and "glasslike" or "allfaces",
	tiles = { "glass.png" },
	paramtype = "light",
	sunlight_propagates = true,
	groups = { wood = 2 },
	sounds = default.node_sound.glass,
})

minetest.register_node("default:fence_wood", {
	description = "Fence",
	drawtype = "fencelike",
	tiles = { "wood.png" },
	inventory_image = "fence.png",
	wield_image = "fence.png",
	selection_box = { type = "regular" },
	paramtype = "light",
	groups = { wood = 5 },
	sounds = default.node_sound.wood,
})

minetest.register_node("default:rail", {
	description = "Rail",
	drawtype = "raillike",
	sunlight_propagates = true,
	walkable = false,
	tiles = {
		"rail.png", "rail_curved.png",
		"rail_t_junction.png", "rail_crossing.png"
	},
	inventory_image = "rail.png",
	wield_image = "rail.png",
	paramtype = "light",
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -0.5+1/16, 0.5},
	},
	groups = { wood = 5 },
	sounds = default.node_sound.other,
})

minetest.register_node("default:ladder", {
	description = "Ladder",
	drawtype = "signlike",
	sunlight_propagates = true,
	walkable = false,
	climbable = true,
	tiles = { "ladder.png" },
	inventory_image = "ladder.png",
	wield_image = "ladder.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	legacy_wallmounted = true,
	selection_box = {
		type = "wallmounted",
		wall_top = {-0.5, 0.42, -0.5, 0.5, 0.49, 0.5},
		wall_bottom = {-0.5, -0.49, -0.5, 0.5, -0.42, 0.5},
		wall_side = {-0.49, -0.5, -0.5, -0.42, 0.5, 0.5},
	},
	groups = { wood = 4 },
	sounds = default.node_sound.wood,
	-- TODO check movement details
})

-- exists in 0.3 as legacy, but we need this as a separate node
minetest.register_node("default:coalstone", {
	description = "Stone with Coal",
	tiles = { "stone.png^mineral_coal.png" },
	groups = { stone = 5 },
	drop = "default:lump_of_coal 2",
	sounds = default.node_sound.stone,
})

-- does not exist as a separate node in 0.3, but we need it as one
minetest.register_node("default:ironstone", {
	description = "Stone with Iron",
	tiles = { "stone.png^mineral_iron.png" },
	groups = { stone = 5 },
	drop = "default:lump_of_iron 2",
	sounds = default.node_sound.stone,
})

minetest.register_node("default:wood", {
	description = "Wood",
	tiles = { "wood.png" },
	groups = { wood = 5 },
	sounds = default.node_sound.wood,
})

minetest.register_node("default:mese", {
	description = "Mese",
	tiles = { "mese.png" },
	groups = { stone = 1 },
	sounds = default.node_sound.stone,
})

minetest.register_node("default:cloud", {
	description = "Cloud",
	tiles = { "cloud.png" },
	groups = { dig_mese = 1, not_in_creative_inventory = 1 },
	sounds = default.node_sound.default,
})

minetest.register_node("default:water_flowing", {
	description = "Water",
	drawtype = "flowingliquid",
	waving = default.modernize.node_waving and 3 or nil,
	tiles = { "water.png" },
	special_tiles = {
		{ name = "water.png", backface_culling = false },
		{ name = "water.png", backface_culling = true },
	},
	use_texture_alpha = "blend",
	paramtype = "light",
	paramtype2 = "flowingliquid",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = default.modernize.drowning and 1 or nil,
	liquidtype = "flowing",
	liquid_alternative_flowing = "default:water_flowing",
	liquid_alternative_source = "default:water_source",
	liquid_viscosity = 1,
	post_effect_color = {a = 64, r = 100, g = 100, b = 200},
	groups = { not_in_creative_inventory = 1 },
	sounds = default.node_sound.water,
})

minetest.register_node("default:water_source", {
	description = "Water Source",
	drawtype = "liquid",
	waving = default.modernize.node_waving and 3 or nil,
	tiles = {
		{ name = "water.png", backface_culling = false },
		{ name = "water.png", backface_culling = true },
	},
	use_texture_alpha = "blend",
	paramtype = "light",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = default.modernize.drowning and 1 or nil,
	liquidtype = "source",
	liquid_alternative_flowing = "default:water_flowing",
	liquid_alternative_source = "default:water_source",
	liquid_viscosity = 1,
	post_effect_color = {a = 64, r = 100, g = 100, b = 200},
	groups = { },
	sounds = default.node_sound.water,
})

-- TODO consider darkening the texture, since the original lava is unlighted
-- despite emitting light (so it looks much darker)

minetest.register_node("default:lava_flowing", {
	description = "Lava",
	drawtype = "flowingliquid",
	tiles = { "lava.png" },
	special_tiles = {
		{ name = "lava.png", backface_culling = false },
		{ name = "lava.png", backface_culling = true },
	},
	use_texture_alpha = "clip",
	paramtype = "light",
	light_source = minetest.LIGHT_MAX - 1,
	paramtype2 = "flowingliquid",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	liquidtype = "flowing",
	liquid_alternative_flowing = "default:lava_flowing",
	liquid_alternative_source = "default:lava_source",
	liquid_viscosity = 7,
	liquid_renewable = not default.modernize.lava_non_renewable,
	damage_per_second = 4 * 2,
	post_effect_color = {a = 192, r = 255, g = 64, b = 0},
	groups = { not_in_creative_inventory = 1 },
})

minetest.register_node("default:lava_source", {
	description = "Lava Source",
	drawtype = "liquid",
	tiles = {
		{ name = "lava.png", backface_culling = false },
		{ name = "lava.png", backface_culling = true },
	},
	use_texture_alpha = "clip",
	paramtype = "light",
	light_source = minetest.LIGHT_MAX - 1,
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	liquidtype = "source",
	liquid_alternative_flowing = "default:lava_flowing",
	liquid_alternative_source = "default:lava_source",
	liquid_viscosity = 7,
	liquid_renewable = not default.modernize.lava_non_renewable,
	damage_per_second = 4 * 2,
	post_effect_color = {a = 192, r = 255, g = 64, b = 0},
	groups = { },
})

minetest.register_node("default:torch", {
	description = "Torch",
	drawtype = "torchlike",
	tiles = { "torch_on_floor.png", "torch_on_ceiling.png", "torch.png" },
	inventory_image = "torch_on_floor.png",
	wield_image = "torch_on_floor.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	legacy_wallmounted = true,
	sunlight_propagates = true,
	walkable = false,
	light_source = minetest.LIGHT_MAX - 1,
	selection_box = {
		type = "wallmounted",
		wall_top = {-0.16, -0.16, -0.16, 0.16, 0.5, 0.16},
		wall_bottom = {-0.16, -0.5, -0.16, 0.16, 0.16, 0.16},
		wall_side = {-0.5, -0.33, -0.16, -0.5+0.33, 0.33, 0.16},
	},
	groups = { dig_hand = 2, air_equivalent = 1 },
	sounds = default.node_sound.default,
})

minetest.register_node("default:sign_wall", {
	description = "Sign",
	drawtype = "signlike",
	tiles = { "sign_wall.png" },
	inventory_image = "sign_wall.png",
	wield_image = "sign_wall.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	legacy_wallmounted = true,
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "wallmounted",
		wall_top = {-0.35, 0.42, -0.4, 0.35, 0.49, 0.4},
		wall_bottom = {-0.35, -0.49, -0.4, 0.35, -0.42, 0.4},
		wall_side = {-0.49, -0.35, -0.4, -0.42, 0.35, 0.4},
	},
	groups = { dig_hand = 1, air_equivalent = 1 },
	sounds = default.node_sound.default,
	on_construct = function(pos)
		local meta = minetest.get_meta(pos)
		meta:set_string("formspec", "field[text;;${text}]")
		meta:set_string("text", "Some sign")
		meta:set_string("infotext", '"' .. meta:get_string("text") .. '"')
	end,
	on_receive_fields = function(pos, formname, fields, sender)
		local meta = minetest.get_meta(pos)
		if not fields.text then
			return
		end
		minetest.log("action", sender:get_player_name() .. ' writes "' ..
			fields.text .. '" to sign at ' .. minetest.pos_to_string(pos))
		meta:set_string("text", fields.text)
		meta:set_string("infotext", '"' .. meta:get_string("text") .. '"')
	end,
})

minetest.register_node("default:chest", {
	description = "Chest",
	tiles = { "chest_top.png", "chest_top.png", "chest_side.png", "chest_side.png", "chest_side.png", "chest_front.png" },
	paramtype2 = "facedir",
	legacy_facedir_simple = true,
	groups = { wood = 6 },
	sounds = default.node_sound.wood,
	on_construct = function(pos)
		local meta = minetest.get_meta(pos)
		meta:set_string("formspec", "size[8,9]"..
			"list[current_name;main;0,0;8,4;]"..
			"list[current_player;main;0,5;8,4;]"..
			"listring[current_name;main]"..
			"listring[current_player;main]")
		meta:set_string("infotext", "Chest")
		local inv = meta:get_inventory()
		inv:set_size("main", 8*4)
	end,
	can_dig = function(pos, player)
		local meta = minetest.get_meta(pos)
		local inv = meta:get_inventory()
		return inv:is_empty("main")
	end,
})

local function can_use_locked_chest(meta, player)
	if meta:get_string("owner") == player:get_player_name() then
		return true
	end
	-- 0.3 uses the 'server' priv for this
	if minetest.check_player_privs(player, "protection_bypass") then
		return true
	end
	return false
end

minetest.register_node("default:chest_locked", {
	description = "Locking Chest",
	tiles = {
		"chest_top.png", "chest_top.png", "chest_side.png", "chest_side.png", "chest_side.png",
		default.modernize.fix_textures and "chest_lock.png" or "chest_lock_old.png"
	},
	paramtype2 = "facedir",
	legacy_facedir_simple = true,
	groups = { wood = 6 },
	sounds = default.node_sound.wood,
	after_place_node = function(pos, player)
		local meta = minetest.get_meta(pos)
		meta:set_string("formspec", "size[8,9]"..
			"list[current_name;main;0,0;8,4;]"..
			"list[current_player;main;0,5;8,4;]"..
			"listring[current_name;main]"..
			"listring[current_player;main]")
		meta:set_string("owner", player:get_player_name())
		meta:set_string("infotext", "Locking Chest")
		-- TODO option to show the player name here
		local inv = meta:get_inventory()
		inv:set_size("main", 8*4)
	end,
	can_dig = function(pos, player)
		local meta = minetest.get_meta(pos)
		local inv = meta:get_inventory()
		return inv:is_empty("main")
	end,
	allow_metadata_inventory_move = function(pos, from_list, from_index, to_list, to_index, count, player)
		local meta = minetest.get_meta(pos)
		if not can_use_locked_chest(meta, player) then
			return 0
		end
		return count
	end,
	allow_metadata_inventory_put = function(pos, listname, index, stack, player)
		local meta = minetest.get_meta(pos)
		if not can_use_locked_chest(meta, player) then
			return 0
		end
		return stack:get_count()
	end,
	allow_metadata_inventory_take = function(pos, listname, index, stack, player)
		local meta = minetest.get_meta(pos)
		if not can_use_locked_chest(meta, player) then
			return 0
		end
		return stack:get_count()
	end,
})

minetest.register_node("default:furnace", {
	description = "Furnace",
	tiles = { "furnace_side.png", "furnace_side.png", "furnace_side.png", "furnace_side.png", "furnace_side.png", "furnace_front.png" },
	paramtype2 = "facedir",
	legacy_facedir_simple = true,
	groups = { stone = 6 },
	drop = "default:cobble 6",
	sounds = default.node_sound.stone,
	-- formspecs / nodetimer is located in furnace.lua
})

minetest.register_node("default:cobble", {
	description = "Cobblestone",
	tiles = { "cobble.png" },
	groups = { stone = 3 },
	sounds = default.node_sound.stone,
})

minetest.register_node("default:mossycobble", {
	description = "Mossy Cobblestone",
	tiles = { "mossycobble.png" },
	groups = { stone = 2 },
	sounds = default.node_sound.stone,
})

minetest.register_node("default:steelblock", {
	description = "Steel Block",
	tiles = { "steel_block.png" },
	groups = { stone = 7 },
	sounds = default.node_sound.stone,
})

-- The original Nyan Cat texture cannot be included due to known trademark issues:
-- https://web.archive.org/web/20200911031901/https://github.com/minetest/minetest_game/issues/1647
minetest.register_node("default:nyancat", {
	description = "PB&J Pup",
	tiles = { "nc_side.png", "nc_side.png", "nc_side.png", "nc_side.png", "nc_back.png", "nc_front.png" },
	paramtype2 = "facedir",
	legacy_facedir_simple = true,
	groups = { stone = 6 },
	sounds = default.node_sound.stone,
})

minetest.register_node("default:nyancat_rainbow", {
	description = "PB&J Pup Candies",
	tiles = { "nc_rb.png" },
	groups = { stone = 6 },
	sounds = default.node_sound.stone,
})

minetest.register_node("default:sapling", {
	description = "Sapling",
	drawtype = "plantlike",
	visual_scale = 1.6, -- TODO need on Y only
	tiles = { "sapling.png" },
	inventory_image = "sapling.png",
	wield_image = "sapling.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	groups = { dig_hand = 2, air_equivalent = 1 },
	sounds = default.node_sound.default,
})

minetest.register_node("default:apple", {
	description = "Apple",
	drawtype = "plantlike",
	tiles = { "apple.png" },
	inventory_image = "apple.png",
	wield_image = "apple.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	groups = { dig_hand = 2, air_equivalent = 1 },
	on_use = minetest.item_eat(4),
	sounds = default.node_sound.default,
})

--
-- Tools
--

local function levels(tbl, m)
	local ret = {}
	for _, n in ipairs(tbl) do
		table.insert(ret, n * m)
	end
	return ret
end

minetest.override_item("", {
	tool_capabilities = {
		-- this is the object_hit_delay in 0.3, SAO code addtl. caps this to
		-- either do full damage or none at all
		full_punch_interval = 0.5,
		groupcaps = {
			dig_hand = { times = { 0.5, 0 }, uses = 0 },
			dirt = { times = levels(default.dirt_levels, 0.75), uses = 0 },
			stone = { times = levels(default.stone_levels, 15), uses = 0 },
			wood = { times = levels(default.wood_levels, 3), uses = 0 },
		},
		damage_groups = { brittle = 5, fleshy = 2 },
	}
})

minetest.register_tool("default:pick_wood", {
	description = "Wooden Pickaxe",
	inventory_image = "tool_woodpick.png",
	tool_capabilities = {
		groupcaps = {
			stone = { times = levels(default.stone_levels, 1.3), uses = 30 },
		},
	},
	sound = default.tool_sound,
})

minetest.register_tool("default:pick_stone", {
	description = "Stone Pickaxe",
	inventory_image = "tool_stonepick.png",
	tool_capabilities = {
		groupcaps = {
			stone = { times = levels(default.stone_levels, 0.75), uses = 100 },
		},
	},
	sound = default.tool_sound,
})

minetest.register_tool("default:pick_steel", {
	description = "Steel Pickaxe",
	inventory_image = "tool_steelpick.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		groupcaps = {
			stone = { times = levels(default.stone_levels, 0.50), uses = 333 },
		},
		damage_groups = { brittle = 7, fleshy = 3 },
		punch_attack_uses = 100,
	},
	sound = default.tool_sound,
})

minetest.register_tool("default:pick_mese", {
	description = "Mese Pickaxe",
	inventory_image = "tool_mesepick.png",
	tool_capabilities = {
		groupcaps = {
			dirt = { times = levels(default.dirt_levels, 0), uses = 1337 },
			stone = { times = levels(default.stone_levels, 0), uses = 1337 },
			wood = { times = levels(default.wood_levels, 0), uses = 1337 },
			dig_mese = { times = { 0 }, uses = 1337 },
		},
	},
	sound = default.tool_sound,
})

minetest.register_tool("default:shovel_wood", {
	description = "Wooden Shovel",
	inventory_image = "tool_woodshovel.png",
	tool_capabilities = {
		groupcaps = {
			dirt = { times = levels(default.dirt_levels, 0.4), uses = 50 },
		},
	},
	sound = default.tool_sound,
})

minetest.register_tool("default:shovel_stone", {
	description = "Stone Shovel",
	inventory_image = "tool_stoneshovel.png",
	tool_capabilities = {
		groupcaps = {
			dirt = { times = levels(default.dirt_levels, 0.2), uses = 150 },
		},
	},
	sound = default.tool_sound,
})

minetest.register_tool("default:shovel_steel", {
	description = "Steel Shovel",
	inventory_image = "tool_steelshovel.png",
	tool_capabilities = {
		groupcaps = {
			dirt = { times = levels(default.dirt_levels, 0.15), uses = 400 },
		},
	},
	sound = default.tool_sound,
})

minetest.register_tool("default:axe_wood", {
	description = "Wooden Axe",
	inventory_image = "tool_woodaxe.png",
	tool_capabilities = {
		groupcaps = {
			wood = { times = levels(default.wood_levels, 1.5), uses = 30 },
		},
	},
	sound = default.tool_sound,
})

minetest.register_tool("default:axe_stone", {
	description = "Stone Axe",
	inventory_image = "tool_stoneaxe.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		groupcaps = {
			wood = { times = levels(default.wood_levels, 0.75), uses = 100 },
		},
		damage_groups = { brittle = 7, fleshy = 3 },
		punch_attack_uses = 100,
	},
	sound = default.tool_sound,
})

minetest.register_tool("default:axe_steel", {
	description = "Steel Axe",
	inventory_image = "tool_steelaxe.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		groupcaps = {
			wood = { times = levels(default.wood_levels, 0.5), uses = 333 },
		},
		damage_groups = { brittle = 9, fleshy = 4 },
		punch_attack_uses = 100,
	},
	sound = default.tool_sound,
})

minetest.register_tool("default:sword_wood", {
	description = "Wooden Sword",
	inventory_image = "tool_woodsword.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		damage_groups = { brittle = 10, fleshy = 4 },
		punch_attack_uses = 100,
	},
	sound = default.tool_sound,
})

minetest.register_tool("default:sword_stone", {
	description = "Stone Sword",
	inventory_image = "tool_stonesword.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		damage_groups = { brittle = 12, fleshy = 6 },
		punch_attack_uses = 100,
	},
	sound = default.tool_sound,
})

minetest.register_tool("default:sword_steel", {
	description = "Steel Sword",
	inventory_image = "tool_steelsword.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		damage_groups = { brittle = 16, fleshy = 8 },
		punch_attack_uses = 100,
	},
	sound = default.tool_sound,
})

--
-- Items
--

if not default.modernize.wieldhand then
	minetest.override_item("", {
		wield_image = "blank.png",
	})
end

minetest.register_craftitem("default:stick", {
	description = "Stick",
	inventory_image = "stick.png",
	groups = { },
})

minetest.register_craftitem("default:paper", {
	description = "Paper",
	inventory_image = "paper.png",
	groups = { },
})

minetest.register_craftitem("default:book", {
	description = "Book",
	inventory_image = "book.png",
	groups = { },
})

minetest.register_craftitem("default:lump_of_coal", {
	description = "Lump of Coal",
	inventory_image = "lump_of_coal.png",
	groups = { },
})

minetest.register_craftitem("default:lump_of_iron", {
	description = "Lump of Iron",
	inventory_image = "lump_of_iron.png",
	groups = { },
})

minetest.register_craftitem("default:lump_of_clay", {
	description = "Lump of Clay",
	inventory_image = "lump_of_clay.png",
	groups = { },
})

minetest.register_craftitem("default:steel_ingot", {
	description = "Steel Ingot",
	inventory_image = "steel_ingot.png",
	groups = { },
})

minetest.register_craftitem("default:clay_brick", {
	description = "Clay Brick",
	inventory_image = "clay_brick.png",
	groups = { },
})

minetest.register_craftitem("default:rat", {
	description = "Rat",
	inventory_image = "rat.png",
	groups = { },
})

minetest.register_craftitem("default:cooked_rat", {
	description = "Cooked Rat",
	inventory_image = "cooked_rat.png",
	groups = { },
	on_use = minetest.item_eat(6),
})

minetest.register_craftitem("default:scorched_stuff", {
	description = "Scorched Stuff",
	inventory_image = "scorched_stuff.png",
	groups = { },
})

minetest.register_craftitem("default:firefly", {
	description = "Firefly",
	inventory_image = "firefly.png",
	groups = { },
})

minetest.register_craftitem("default:apple_iron", {
	description = "Iron Apple",
	inventory_image = "apple_iron.png",
	groups = { },
	on_use = minetest.item_eat(8),
})

--
-- Crafting
--

minetest.register_craft({
	output = "default:wood 4",
	recipe = {
		{"default:tree"},
	}
})

minetest.register_craft({
	output = "default:stick 4",
	recipe = {
		{"default:wood"},
	}
})

minetest.register_craft({
	output = "default:fence 2",
	recipe = {
		{"", "", ""},
		{"default:wood", "default:wood", "default:wood"},
		{"default:wood", "default:wood", "default:wood"},
	}
})

minetest.register_craft({
	output = "default:sign_wall",
	recipe = {
		{"default:wood", "default:wood", "default:wood"},
		{"default:wood", "default:wood", "default:wood"},
		{"", "default:stick", ""},
	}
})

minetest.register_craft({
	output = "default:torch 4",
	recipe = {
		{"default:lump_of_coal"},
		{"default:stick"},
	}
})

minetest.register_craft({
	output = "default:pick_wood",
	recipe = {
		{"default:wood", "default:wood", "default:wood"},
		{"", "default:stick", ""},
		{"", "default:stick", ""},
	}
})

minetest.register_craft({
	output = "default:pick_stone",
	recipe = {
		{"default:cobble", "default:cobble", "default:cobble"},
		{"", "default:stick", ""},
		{"", "default:stick", ""},
	}
})

minetest.register_craft({
	output = "default:pick_steel",
	recipe = {
		{"default:steel_ingot", "default:steel_ingot", "default:steel_ingot"},
		{"", "default:stick", ""},
		{"", "default:stick", ""},
	}
})

minetest.register_craft({
	output = "default:pick_mese",
	recipe = {
		{"default:mese", "default:mese", "default:mese"},
		{"", "default:stick", ""},
		{"", "default:stick", ""},
	}
})

minetest.register_craft({
	output = "default:shovel_wood",
	recipe = {
		{"default:wood"},
		{"default:stick"},
		{"default:stick"},
	}
})

minetest.register_craft({
	output = "default:shovel_stone",
	recipe = {
		{"default:cobble"},
		{"default:stick"},
		{"default:stick"},
	}
})

minetest.register_craft({
	output = "default:shovel_steel",
	recipe = {
		{"default:steel_ingot"},
		{"default:stick"},
		{"default:stick"},
	}
})

minetest.register_craft({
	output = "default:axe_wood",
	recipe = {
		{"default:wood", "default:wood", ""},
		{"default:wood", "default:stick", ""},
		{"", "default:stick", ""},
	}
})

minetest.register_craft({
	output = "default:axe_stone",
	recipe = {
		{"default:cobble", "default:cobble", ""},
		{"default:cobble", "default:stick", ""},
		{"", "default:stick", ""},
	}
})

minetest.register_craft({
	output = "default:axe_steel",
	recipe = {
		{"default:steel_ingot", "default:steel_ingot", ""},
		{"default:steel_ingot", "default:stick", ""},
		{"", "default:stick", ""},
	}
})

minetest.register_craft({
	output = "default:sword_wood",
	recipe = {
		{"default:wood"},
		{"default:wood"},
		{"default:stick"},
	}
})

minetest.register_craft({
	output = "default:sword_stone",
	recipe = {
		{"default:cobble"},
		{"default:cobble"},
		{"default:stick"},
	}
})

minetest.register_craft({
	output = "default:sword_steel",
	recipe = {
		{"default:steel_ingot"},
		{"default:steel_ingot"},
		{"default:stick"},
	}
})

minetest.register_craft({
	output = "default:rail 15",
	recipe = {
		{"default:steel_ingot", "default:stick", "default:steel_ingot"},
		{"default:steel_ingot", "default:stick", "default:steel_ingot"},
		{"default:steel_ingot", "default:stick", "default:steel_ingot"},
	}
})

minetest.register_craft({
	output = "default:chest",
	recipe = {
		{"default:wood", "default:wood", "default:wood"},
		{"default:wood", "", "default:wood"},
		{"default:wood", "default:wood", "default:wood"},
	}
})

minetest.register_craft({
	output = "default:chest_locked",
	recipe = {
		{"default:wood", "default:wood", "default:wood"},
		{"default:wood", "default:steel_ingot", "default:wood"},
		{"default:wood", "default:wood", "default:wood"},
	}
})

minetest.register_craft({
	output = "default:furnace",
	recipe = {
		{"default:cobble", "default:cobble", "default:cobble"},
		{"default:cobble", "", "default:cobble"},
		{"default:cobble", "default:cobble", "default:cobble"},
	}
})

minetest.register_craft({
	output = "default:steelblock",
	recipe = {
		{"default:steel_ingot", "default:steel_ingot", "default:steel_ingot"},
		{"default:steel_ingot", "default:steel_ingot", "default:steel_ingot"},
		{"default:steel_ingot", "default:steel_ingot", "default:steel_ingot"},
	}
})

minetest.register_craft({
	output = "default:sandstone",
	recipe = {
		{"default:sand", "default:sand"},
		{"default:sand", "default:sand"},
	}
})

minetest.register_craft({
	output = "default:clay",
	recipe = {
		{"default:lump_of_clay", "default:lump_of_clay"},
		{"default:lump_of_clay", "default:lump_of_clay"},
	}
})

minetest.register_craft({
	output = "default:brick",
	recipe = {
		{"default:clay_brick", "default:clay_brick"},
		{"default:clay_brick", "default:clay_brick"},
	}
})

minetest.register_craft({
	output = "default:paper",
	recipe = {
		{"default:papyrus", "default:papyrus", "default:papyrus"},
	}
})

minetest.register_craft({
	output = "default:book",
	recipe = {
		{"default:paper"},
		{"default:paper"},
		{"default:paper"},
	}
})

minetest.register_craft({
	output = "default:bookshelf",
	recipe = {
		{"default:wood", "default:wood", "default:wood"},
		{"default:book", "default:book", "default:book"},
		{"default:wood", "default:wood", "default:wood"},
	}
})

minetest.register_craft({
	output = "default:ladder",
	recipe = {
		{"default:stick", "", "default:stick"},
		{"default:stick", "default:stick", "default:stick"},
		{"default:stick", "", "default:stick"},
	}
})

minetest.register_craft({
	output = "default:apple_iron",
	recipe = {
		{"", "default:steel_ingot", ""},
		{"default:steel_ingot", "default:apple", "default:steel_ingot"},
		{"", "default:steel_ingot", ""},
	}
})

--
-- Fuels & Cooking
--

for item, time in pairs({
	["default:tree"]         = 30,
	["default:jungletree"]   = 30,
	["default:fence_wood"]   = 30/2,
	["default:wood"]         = 30/4,
	["default:bookshelf"]    = 30/4,
	["default:leaves"]       = 30/16,
	["default:papyrus"]      = 30/32,
	["default:junglegrass"]  = 30/32,
	["default:cactus"]       = 30/4,
	["default:stick"]        = 30/4/4,
	["default:lump_of_coal"] = 40,
}) do
	minetest.register_craft({
		type = "fuel",
		recipe = item,
		burntime = time,
	})
end

for item_in, item_out in pairs({
	["default:tree"]         = "default:lump_of_coal",
	["default:cobble"]       = "default:stone",
	["default:sand"]         = "default:glass",
	["default:lump_of_iron"] = "default:steel_ingot",
	["default:lump_of_clay"] = "default:clay_brick",
	["default:rat"]          = "default:cooked_rat",
	["default:cooked_rat"]   = "default:scorched_stuff",
}) do
	minetest.register_craft({
		type = "cooking",
		output = item_out,
		recipe = item_in,
	})
end

--
-- Includes
--

local modpath = minetest.get_modpath(minetest.get_current_modname())
dofile(modpath .. "/bucket.lua")


minetest.register_node("default:bricc", {
	description = "stone bricks",
	tiles = {"cobble_bricks.png"},
	groups = {stone = 2},
})

minetest.register_craft({
	output = "default:bricc",
	recipe = {{"default:brick", "default:stone"}}

})

minetest.register_craft({
	output = "default:mese 8",
	recipe = {{"default:dirt", "default:steel_ingot"}}
})

minetest.register_node("default:dirt_block", {
	description = "Dirt",
	tiles = {"dirt1.png"},
    groups = {plastic = 5},
})
minetest.register_node("default:stone_block", {
	description = "Stone",
	tiles = {"stone1.png"},
    groups = {plastic = 5},
})
minetest.register_node("default:cobble2", {
	description = "cobble",
	tiles = {"coobble.png"},
    groups = {plastic = 5},
})
minetest.register_node("default:grass_covered_dirt1_block", {
	description = "Grass Block",
	tiles = {"grass1.png", "dirt1.png", "grass_side1.png"},
    groups = {plastic = 5},
})
minetest.register_node("default:glass1", {
	description = "Glass",
	tiles = {"glass1.png"},
    drawtype = "allfaces",
    sunlight_propagates = true,
    paramtype = "light",
     -- TODO: Understand paramtype+use_texture_alpha...
	use_texture_alpha = minetest.features.use_texture_alpha_string_modes and "blend" or true,
    groups = {plastic = 5},
})
minetest.register_node("default:grass_block", {
	description = "Block of Grass",
	tiles = {"grass1.png"},
    groups = {plastic = 5},
})
minetest.register_node("default:wooden", {
	description = "Wood",
	tiles = {"minetestrpg_blocks_wood_v.png", "minetestrpg_blocks_wood_v.png", "minetestrpg_blocks_wood_h.png"},
    groups = {plastic = 5},
})
minetest.register_node("default:leaves1", {
	description = "Leaves 1",
	tiles = {"minetestrpg_blocks_leaves1.png"},
    drawtype = "allfaces",
    sunlight_propagates = true,
    paramtype = "light",
    groups = {plastic = 5},
})
minetest.register_node("default:fake_sky", {
	description = "FakeSky",
	tiles = {"minetestrpg_blocks_fakesky.png"},
    sunlight_propagates = true,
    paramtype = "light",
    groups = {plastic = 5},
})
minetest.register_node("default:flag_blue", {
	description = "2D flag",
  visual_scale = 2.0,
	tiles = {"flag_blue.png"},
    drawtype = "torchlike",
    sunlight_propagates = true,
    paramtype = "light",
    groups = {plastic = 5, dig_immediate = 3},
})

minetest.register_node("default:pattern_ponder", {
	description = "Dark Bricks",
	tiles = {"grassland.png"},
    groups = {plastic = 5},
})

minetest.register_node("default:wall", {
	description = ("wahh"),
	inventory_image = minetest.inventorycube("di.png"),
	wield_image = minetest.inventorycube("di.png"),
	tiles = {"di.png"},
	groups = {dig_mese=1},
	drawtype = "allfaces",
  paramtype = "light",
	air_equivalent = true,
	sunlight_propagates = true,
})

minetest.register_node("default:dee", {
	description = "decorative",
	tiles = {"c.png"},
	groups = {wood = 2},
})

minetest.register_craft({
	output = "default:dee",
	recipe = {{"default:tree", "default:tree"}}
})

minetest.register_node("default:is", {
	description = "is",
	tiles = {"is.png"},
	groups = {stone = 2},
})

minetest.register_craft({
	output = "infinite_wood:is 2",
	recipe = {{"default:s", "default:mese"}}
})

minetest.register_craft({
	output = "default:tree 8",
	recipe = {{"infinite_wood:fake_diamond", "infinite_wood:fake_diamond"}}
})

minetest.register_node("default:s", {
	description = "jungle wood",
	tiles = {"d.png"},
  groups = {wood = 1},
})

minetest.register_node("default:ooh", {
	description = "a",
	tiles = {"ooh.png"},
	groups = {oddly_breakable_by_hand = 2},
})

minetest.register_craft({
	output = "default:s 4",
	recipe = {{"default:jungletree"}}
})

minetest.register_craft({
	output = "default:ooh",
	recipe = {{"default:s", "default:s", "default:s"}}
})

minetest.register_craftitem("default:blueprints", {
	description = "Blueprints",
	inventory_image = "Blueprints.png",
})



minetest.register_craft({
	output = "default:mese",
	recipe = {{"default:blueprints", "default:steelblock"}},
	replacements = {
		{"default:blueprints", "default:blueprints"},
		{"default:tree", "default:tree"}
	}
})

minetest.register_craft({
	output = "default:blueprints",
	recipe = {{"default:stick", "woolmod:wool"}}
})




-- Barriers
-- Red: bad portal
-- Pink: Unfilled frames
-- Blue: Unconnected
-- Gray: Fake portal

minetest.register_node("default:barrier_pink", {
	description = "Barrier",
	drawtype = "allfaces_optional",
	waving = 2,
	light_source = 1,
	paramtype = "light",
	tiles = {name = "barrier_pink.png"},
	--walkable = false,
	diggable = false,
})

minetest.register_node("default:barrier_red", {
	description = "Barrier",
	drawtype = "allfaces_optional",
	waving = 2,
	light_source = 1,
	paramtype = "light",
	tiles = {name = "barrier_red.png"},
	--walkable = false,
	diggable = false,
})

minetest.register_node("default:barrier_gray", {
	description = "Barrier",
	drawtype = "allfaces_optional",
	waving = 2,
	light_source = 1,
	paramtype = "light",
	tiles = {name = "barrier_gray.png"},
	--walkable = false,
	diggable = false,
})

minetest.register_node("default:barrier", {
	description = "Barrier",
	drawtype = "allfaces_optional",
	waving = 2,
	light_source = 1,
	paramtype = "light",
	tiles = {name = "barrier.png"},
	--walkable = false,
	diggable = false,
})

minetest.register_node("default:aaaaaaaaaa", {
	description = "P",
	drawtype = "glasslike",
	tiles = {"eaves.png"},
	paramtype = "light",
	walkable = false,
	pointable = true,
	sunlight_propagates = true,
})

minetest.register_node("default:wall", {
	description = "Wall",
	tiles = {"wall.png"},
	--drawtype = "allfaces_optional",
	--use_texture_alpha = "blend",
})



minetest.register_node("default:frame", {
	description = "Frame",
	--paramtype = "light",
	light_source = 8,
	drawtype = "allfaces",
	use_texture_alpha = "blend",
	tiles = {"frame.png"},
	buildable_to = false,
})




local sound_def = {
    dig = "soundstuff_mono"
}

minetest.register_node("default:glowstone", {
    description="Glowstone",
    tiles={"mts_lights_glowstone.png"},
    sounds = sound_def,
    groups={plastic = 3},
    light_source = 10
})

minetest.register_node("default:pocket_sun", {
    description="Pocket Sun",
    tiles={"mts_lights_pocket_sun.png"},
    sounds = sound_def,
    groups={plastic =30},
    light_source = 14
})

minetest.register_node("default:wl", {
	description = ("Inll"),
	inventory_image = minetest.inventorycube("i.png"),
	wield_image = minetest.inventorycube("i.png"),
	tiles = {"i.png"},
	groups = {stone=1},
	drawtype = "allfaces_optional",
  paramtype = "light",
	air_equivalent = true,
	sunlight_propagates = true,
	on_blast = function()
  end,
})

minetest.register_node("default:m1n3t3st", {
	description = "MINETEST SPECIFICATIONS BLOCK [ADMINS ONLY]",
	tiles = {"su1.png"},
	groups = {oddly_breakable_by_hand = 2},
})

minetest.register_craft({
	output = "default:m1n3t3st",
	recipe = {{"default:tree", "air"}}
})

minetest.register_node("default:reinwood", {
	description = "Reinforced wood",
	tiles = {"wood_reinforced.png"},
	groups = {stone = 2},
})

minetest.register_craft({
	output = "default:reinwood 2",
	recipe = {{"default:wood", "default:stone"}}
})

minetest.register_craft({
	output = "default:tree 8",
	recipe = {{"default:stick", "default_jungletree"}}
})

minetest.register_tool("default:ADpick", {
	description = "pickaxe (admin)",
	inventory_image = "pick.png",
	tool_capabilities = {
		groupcaps={
			plastic = {maxlevel=12496, times = {42, 42, 42, 42, 42},dirt=3,wood=3,stone=3,cracky=3,choppy=3,snappy=3},
		},
		damage_groups = {fleshy=12496},
	},
	groups = {pickaxe = 1}
})


minetest.register_node("default:notimetoliveitcomeineedhelppleasehelpmeimgoinginsanehelpmepainagonydeath666exe", {
	description = ("black spherical window"),
	drawtype = "allfaces",
	paramtype = "light",
	tiles = { "low_air.png" },
  groups = { wood = 3 },
})

minetest.register_node("default:reinglass", {
	description = ("Reinforced glass"),
	inventory_image = minetest.inventorycube("invisible_wall.png"),
	wield_image = minetest.inventorycube("invisible_wall.png"),
	tiles = {"invisible_wall.png"},
	groups = {stone=1},
	drawtype = "glasslike",
  paramtype = "light",
	air_equivalent = true,
	sunlight_propagates = true,
	on_blast = function()
  end,
})


minetest.register_tool("default:digga",  {
	description = ("p1ck4x3"),
	inventory_image = "cartoonpick.png",
	tool_capabilities = {
		full_punch_intervall = 1.5,
		max_drop_level = 1,
		groupcaps = {
			easy = {
				uses = 100,
				maxlevel = 1,
				times = {[1]=0.6},
			},
		},
		damage_groups = {fleshy=1},
	},
})

  minetest.register_craft({
    type = "shaped",
    output = "default:reinglass 5",
    recipe = {
    {"","default:glass",""},
    {"default:glass","default:steel_ingot","default:glass"},
    {"","default:glass",""},
    },
  })

minetest.register_node("default:test", {
description = ("test"),
drawtype = "allfaces",
paramtype = "light",
tiles = { "test.png" },

groups = { dig_immediate = 3 },
})


minetest.register_node("default:crusher", {
description = ("crusher (not functional yet)"),
drawtype = "normal",
paramtype = "light",
tiles = { "crusher_top.png","crusher_front.png","crusher_back.png","crusher_side.png" },

groups = { dig_mese = 1 },
})


minetest.register_node("default:solidpitch", {
description = ("solid pitch"),
drawtype = "allfaces",
paramtype = "wallmounted",
tiles = { "69.png" },

groups = { stone = 3 },
})


minetest.register_node("default:three_dots", {
description = ("..."),
drawtype = "allfaces",
paramtype = "wallmounted",
tiles = { "3dot.png" },

groups = { dig_immediate = 3 },
})

minetest.register_node("default:pat", {
description = ("pattern"),
drawtype = "allfaces",
paramtype = "wallmounted",
tiles = { "naw.png" },

groups = { dig_immediate = 3 },
})

minetest.register_node("default:err", {
description = ("72829372947257"),
drawtype = "allfaces",
paramtype = "wallmounted",
tiles = { "90.png" },

groups = { dig_immediate = 3 },
})


-- Original reference:
-- https://github.com/minetest/minetest/blob/stable-0.3/src/environment.cpp#L929
-- treegen https://github.com/minetest/minetest/blob/stable-0.3/src/mapgen.cpp#L83

-- Convert grass into mud if under something else than air
minetest.register_abm({
	label = "Mud to Grass",
	nodenames = {"default:dirt"},
	neighbors = {"air", "group:air_equivalent"},
	interval = 10,
	chance = 20,
	catch_up = false, -- Back in my day we had no such thing
	action = function(pos, node)
		local p1 = vector.offset(pos, 0, 1, 0)
		local above = minetest.get_node(p1)
		local has_air = above.name == "air" or minetest.get_item_group(above.name, "air_equivalent") > 0
		if has_air and minetest.get_node_light(p1) >= 13 then
			node.name = "default:dirt_with_grass"
			minetest.swap_node(pos, node)
		end
	end,
})

-- Convert grass into mud if under something else than air
minetest.register_abm({
	label = "Grass to Mud",
	nodenames = {"default:dirt_with_grass"},
	interval = 10,
	catch_up = false,
	action = function(pos, node)
		local above = minetest.get_node(vector.offset(pos, 0, 1, 0))
		if above.name ~= "air" and minetest.get_item_group(above.name, "air_equivalent") == 0 then
			node.name = "default:dirt"
			minetest.swap_node(pos, node)
		end
	end,
})

-- Rats spawn around regular trees
minetest.register_abm({
	label = "Rat Spawning",
	nodenames = {"default:tree", "default:jungletree"},
	interval = 10,
	chance = 200,
	catch_up = false,
	action = function(pos, node, active_object_count, active_object_count_wider)
		if active_object_count_wider > 0 then
			return
		end
		pos.x = pos.x + math.random(-2, 2)
		pos.z = pos.z + math.random(-2, 2)
		node = minetest.get_node(pos)
		local below = minetest.get_node(vector.offset(pos, 0, -1, 0))
		if below.name == "default:dirt_with_grass" and node.name == "air" then
			minetest.add_entity(pos, "default:rat")
		end
	end,
})

-- Fun things spawn in caves and dungeons


-- Make trees from saplings!
default.make_tree = function(vm, p0, is_apple_tree)
	local n_tree = {name = "default:tree"}
	local n_leaves = {name = "default:leaves"}
	local n_apple = {name = "default:apple"}

	local trunk_h = math.random(4, 5)
	local p1 = p0
	for ii = 1, trunk_h do
		vm:set_node_at(p1, n_tree)
		p1.y = p1.y + 1
	end

	-- p1 is now the last piece of the trunk
	p1.y = p1.y - 1

	local leaves_a = VoxelArea:new({MinEdge = vector.new(-2,-1,-2),
		MaxEdge = vector.new(2,1,2)})
	local leaves_d = {}

	-- Force leaves near the end of the trunk
	local d = 1
	for z = -d, d do
	for y = -d, d do
	for x = -d, d do
		leaves_d[leaves_a:index(x, y, z)] = true
	end
	end
	end

	-- Add leaves randomly
	for iii = 1, 7 do
		local p = vector.combine(leaves_a.MinEdge, vector.add(leaves_a.MaxEdge, -d), math.random)

		for z = 0, d do
		for y = 0, d do
		for x = 0, d do
			leaves_d[leaves_a:index(p.x + x, p.y + y, p.z + z)] = true
		end
		end
		end
	end

	-- Blit leaves to vmanip
	for z = leaves_a.MinEdge.z, leaves_a.MaxEdge.z do
	for y = leaves_a.MinEdge.y, leaves_a.MaxEdge.y do
	for x = leaves_a.MinEdge.x, leaves_a.MaxEdge.x do
		local p = vector.add(vector.new(x, y, z), p1)
		local node = vm:get_node_at(p)
		if node.name == "air" or node.name == "ignore" then
			if leaves_d[leaves_a:index(x, y, z)] then
				if is_apple_tree and math.random(0, 99) < 10 then
					vm:set_node_at(p, n_apple)
				else
					vm:set_node_at(p, n_leaves)
				end
			end
		end
	end
	end
	end
end

minetest.register_abm({
	label = "Saplings",
	nodenames = {"default:sapling"},
	interval = 10,
	chance = 50,
	catch_up = false,
	action = function(pos, node)
		minetest.log("action", "A sapling grows into a tree at " ..
			minetest.pos_to_string(pos))

		local vm = minetest.get_voxel_manip()
		-- 1 extra block on each side
		local bs = vector.new(minetest.MAP_BLOCKSIZE, minetest.MAP_BLOCKSIZE, minetest.MAP_BLOCKSIZE)
		vm:read_from_map(vector.subtract(pos, bs), vector.add(pos, bs))

		local is_apple_tree = math.random(0, 4) == 0
		default.make_tree(vm, pos, is_apple_tree)

		if default.modernize.sounds then
			-- a tree magically pops into existence so add a sound cue
			minetest.sound_play("leaves", {
				pos = pos
			}, true)
		end

		vm:write_to_map()
	end,
})


-- Original references:
-- how it works https://github.com/minetest/minetest/blob/stable-0.3/src/content_sao.cpp
-- how it looks https://github.com/minetest/minetest/blob/stable-0.3/src/content_cao.cpp

--
-- helpers
--

assert(minetest.has_feature("object_step_has_moveresult"))

local gravity = tonumber(minetest.settings:get("movement_gravity")) or 9.81

local function limit_interval(self, prop, dtime, wanted_interval)
	self[prop] = self[prop] + dtime
	if self[prop] < wanted_interval then
		return false
	end
	self[prop] = self[prop] - wanted_interval
	return true
end

-- Y is copied, X and Z change is limited
local function accelerate_xz(vel, target_vel, max_increase)
	local d_wanted = vector.subtract(target_vel, vel)
	d_wanted.y = 0
	local dl = vector.length(d_wanted)
	dl = math.min(dl, max_increase)
	local d = vector.multiply(vector.normalize(d_wanted), dl)
	return vector.new(vel.x + d.x, target_vel.y, vel.z + d.z)
end

local function distance_xz(a, b)
	local x = a.x - b.x
	local z = a.z - b.z
	return math.sqrt(x * x + z * z)
end

local function checkFreePosition(p0, size)
	local nodes = minetest.find_nodes_in_area(p0,
		vector.add(vector.add(p0, size), -1), "air", true)
	if not nodes.air then
		return false
	end
	return #nodes.air == size.x * size.y * size.z
end

local function checkWalkablePosition(p0)
	local node = minetest.get_node(vector.offset(p0, 0, -1, 0))
	return node.name ~= "air"
end

local function checkFreeAndWalkablePosition(p0, size)
	return checkFreePosition(p0, size) and checkWalkablePosition(p0)
end

local function explodeSquare(p0, size)
	if default.modernize.sounds then
		minetest.sound_play("explode", {
			pos = p0,
		}, true)
	end
	-- FIXME: callbacks / indestructability?
	local positions = {}
	for dx = 0, size.x - 1 do
	for dy = 0, size.y - 1 do
	for dz = 0, size.z - 1 do
		positions[#positions+1] = vector.offset(p0, dx, dy, dz)
	end
	end
	end
	minetest.bulk_set_node(positions, {name="air"})
end

--
-- ItemSAO
--

if not default.modernize.new_item_entity then
	minetest.log("warning", "old ItemSAO unimplemented")
end

--
-- RatSAO1
--

local RatSAO1 = {
	initial_properties = {
		physical = true,
		collide_with_objects = false,
		collisionbox = {-1/3, 0, -1/3, 1/3, 2/3, 1/3},
		selectionbox = {-1/3, 0, -1/3, 1/3, 1/2, 1/3},
		visual = "mesh",
		mesh = "rat.obj",
		textures = {"rat.png"},
    use_texture_alpha = true,
		backface_culling = false,
	},

	is_active = false,
	inactive_interval = 0,
	oldpos = vector.zero(),
	counter1 = 0,
	counter2 = 0,
	sound_timer = 0,
}

function RatSAO1:on_activate(staticdata, dtime_s)
	self.object:set_yaw(math.random(0, 6))
	self.object:set_acceleration(vector.new(0, -gravity, 0))
	self.object:set_armor_groups({punch_operable=1})
end

function RatSAO1:on_step(dtime, moveresult)
	if not self.is_active then
		-- FIXME physics are actually turned off if inactive
		if not limit_interval(self, "inactive_interval", dtime, 0.5) then
			return
		end
	end

	-- Move around if some player is close
	local pos = self.object:get_pos()
	self.is_active = false
	for _, player in ipairs(minetest.get_connected_players()) do
		if vector.distance(player:get_pos(), pos) < 10 then
			self.is_active = true
		end
	end

	local vel = self.object:get_velocity()
	if not self.is_active then
		vel.x = 0
		vel.z = 0
	else
		-- Move around
		local yaw = self.object:get_yaw()
		local dir = vector.new(math.cos(yaw), 0, math.sin(yaw))
		local speed = 2
		vel.x = speed * dir.x
		vel.z = speed * dir.z

		if moveresult.touching_ground and vector.distance(self.oldpos, pos)
			< dtime * speed / 2 then
			self.counter1 = self.counter1 - dtime
			if self.counter1 < 0 then
				self.counter1 = self.counter1 + 1
				vel.y = 5
			end
		end

		self.counter2 = self.counter2 - dtime
		if self.counter2 < 0 then
			self.counter2 = self.counter2 + math.random(0, 300) / 100
			self.object:set_yaw(yaw + math.random(-100, 100) / 100 * math.pi)
		end

		self.sound_timer = self.sound_timer - dtime
		if self.sound_timer < 0 then
			if moveresult.touching_ground and default.modernize.sounds then
				minetest.sound_play("rat", {
					pos = pos,
				}, true)
			end
			self.sound_timer = self.sound_timer + 0.1 * math.random(40, 70)
		end
	end
	self.object:set_velocity(vel)

	self.oldpos = pos
end

function RatSAO1:on_punch(hitter)
	local item = "default:rat"
	minetest.log("action", hitter:get_player_name() .. " picked up " .. item)
	if not minetest.is_creative_enabled(hitter:get_player_name()) then
		hitter:get_inventory():add_item("main", item)
	end
	self.object:remove()
end

minetest.register_entity("default:rat", RatSAO1)

--
-- furnace
--



local function get_cooked(item)
	if not item:is_empty() then
		local ret = minetest.get_craft_result({
			method = "cooking",
			items = {item}
		})
		if not ret.item:is_empty() then
			return ret
		end
	end
end

-- TODO should probably support replacements

-- Note that the engine only reports meta updates if values actually change
-- so this function has okayish efficiency despite updating the infotext every run.
local function furnace_step(meta, inv, dtime)
	local src_item = inv:get_stack("src", 1)
	local cooked = get_cooked(src_item)

	local room_available = cooked and inv:room_for_item("dst", cooked.item)

	-- Start only if there are free slots in dst, so that it can
	-- accomodate any result item
	local src_totaltime = 0
	if room_available then
		src_totaltime = cooked.time
	else
		meta:set_float("src_time", 0)
	end

	-- If fuel is burning, increment the burn counters.
	-- If item finishes cooking, move it to result.
	local m_fuel_time = meta:get_float("fuel_time")
	local m_fuel_totaltime = meta:get_float("fuel_totaltime")
	if m_fuel_time < m_fuel_totaltime then
		m_fuel_time = m_fuel_time + dtime
		local m_src_time = meta:get_float("src_time")
		m_src_time = m_src_time + dtime
		if m_src_time >= src_totaltime and src_totaltime > 0.001 and cooked then
			inv:add_item("dst", cooked.item)
			src_item:take_item(1)
			inv:set_stack("src", 1, src_item)
			m_src_time = 0
		end

		meta:set_float("fuel_time", m_fuel_time)
		meta:set_float("src_time", m_src_time)
		local s = "Furnace is active"
		if m_fuel_totaltime > 3 then -- so it doesn't always show (0%) for weak fuel
			s = s .. " (" .. math.floor(m_fuel_time/m_fuel_totaltime*100) .. "%)"
		end
		meta:set_string("infotext", s)

		-- If the fuel was not used up this step, just keep burning it
		if m_fuel_time < m_fuel_totaltime then
			return
		end
	else
		local s = "Furnace is inactive"
		if cooked then
			s = room_available and "Furnace is out of fuel" or "Furnace is overloaded"
		end
		meta:set_string("infotext", s)
	end

	-- Get the source again in case it has all burned
	if src_item:is_empty() then
		src_item = inv:get_stack("src", 1)
		cooked = get_cooked(src_item)
		room_available = cooked and inv:room_for_item("dst", cooked.item)
	end

	-- If there is no source item, or the source item is not cookable,
	-- or the furnace became overloaded, stop.
	if not room_available then
		return false
	end

	local fuel_item = inv:get_stack("fuel", 1)
	local fuel = minetest.get_craft_result({
		method = "fuel",
		items = {fuel_item}
	})
	if fuel.time > 0 then
		meta:set_float("fuel_totaltime", fuel.time)
		meta:set_float("fuel_time", 0)
		fuel_item:take_item(1)
		inv:set_stack("fuel", 1, fuel_item)
	else
		-- No fuel, stop loop.
		meta:set_string("infotext", "Furnace is out of fuel")
		return false
	end
end

local FURNACE_INTERVAL = 2
local FURNACE_FORMSPEC = (
	"size[8,9]"..
	"list[current_name;fuel;2,3;1,1;]"..
	"list[current_name;src;2,1;1,1;]"..
	"list[current_name;dst;5,1;2,2;]"..
	"list[current_player;main;0,5;8,4;]"..
	"listring[context;dst]"..
	"listring[current_player;main]"..
	"listring[context;src]"..
	"listring[current_player;main]"..
	"listring[context;fuel]"..
	"listring[current_player;main]"
)

minetest.override_item("default:furnace", {
	on_construct = function(pos)
		local meta = minetest.get_meta(pos)
		meta:set_string("formspec", FURNACE_FORMSPEC)
		meta:set_string("infotext", "Furnace is inactive")
		local inv = meta:get_inventory()
		inv:set_size("fuel", 1)
		inv:set_size("src", 1)
		inv:set_size("dst", 4)

		minetest.get_node_timer(pos):start(FURNACE_INTERVAL)
	end,

	can_dig = function(pos, player)
		local meta = minetest.get_meta(pos)
		local inv = meta:get_inventory()
		return inv:is_empty("fuel") and inv:is_empty("src") and inv:is_empty("dest")
	end,

	on_timer = function(pos, elapsed)
		local meta = minetest.get_meta(pos)
		local inv = meta:get_inventory()

		if elapsed > 60 then
			minetest.log("info", "Furnace stepping a long time (" .. elapsed .. ")")
		end
		-- Update at a fixed frequency
		while elapsed >= FURNACE_INTERVAL do
			if furnace_step(meta, inv, FURNACE_INTERVAL) == false then
				break
			end
			elapsed = elapsed - FURNACE_INTERVAL
		end
		return true
	end,

	--on_punch = function(pos, node)
	--	local meta = minetest.get_meta(pos)
	--	print(dump(meta:to_table()))
	--end,
})


-- Original references:
-- https://github.com/minetest/minetest/blob/stable-0.3/src/mapgen.cpp#L1667

--
-- General
--

if table.indexof({"v6", "singlenode"}, minetest.get_mapgen_setting("mg_name")) == -1 then
	error("Minetest Classic only works with the v6 map generator")
end

assert(minetest.MAP_BLOCKSIZE == 16) -- calculations would need to be redone

local water_level = tonumber(minetest.get_mapgen_setting("water_level"))

local chunksize = tonumber(minetest.get_mapgen_setting("chunksize"))
-- whole number multiplier used for mapgen processes to account for size difference
-- (0.3 generates one MapBlock at once, later versions use 1 MapChunk = 5*5*5 MapBlocks)
local chunksize_c = math.pow(chunksize, 3)

local FIVE_DIRS = {
	vector.new(-1, 0,  0),
	vector.new( 1, 0,  0),
	vector.new( 0, 0, -1),
	vector.new( 0, 0,  1),
	vector.new( 0, 1,  0),
}

-- force snow biomes off if the world was created with them enabled
do
	local spflags = minetest.get_mapgen_setting("mgv6_spflags")
	spflags = string.split(spflags, ",", false)
	for i, v in ipairs(spflags) do
		if v:find("snowbiomes") then
			spflags[i] = "nosnowbiomes"
		end
	end
	spflags = table.concat(spflags, ",")
	minetest.set_mapgen_setting("mgv6_spflags", spflags, true)
end

for k, v in pairs({
	mapgen_stone = "default:stone",
	mapgen_water_source = "default:water_source",
	mapgen_lava_source = "default:lava_source",
	mapgen_cobble = "default:cobble",
	mapgen_dirt = "default:dirt",
	mapgen_dirt_with_grass = "default:dirt_with_grass",
	mapgen_sand = "default:sand",
	mapgen_tree = "default:tree",
	mapgen_leaves = "default:leaves",
	mapgen_apple = "default:apple",
	mapgen_jungletree = "default:jungletree",
	mapgen_jungleleaves = "default:jungleleaves",
	mapgen_junglegrass = "default:junglegrass",
	mapgen_cobble = "default:cobble",
	mapgen_mossycobble = "default:mossycobble",
}) do
	minetest.register_alias(k, v)
end

--
-- Decorations
--

local np_tree_amount = {
	-- transformed from '0.04 * (x+0.39) / (1+0.39)'
	offset = 0.01122,
	scale = 0.02877,
	spread = vector.new(125, 125, 125),
	seed = 2,
	octaves = 4,
	persistence = 0.66,
	lacunarity = 2,
	-- Limitation: Can't model that jungles are supposed to have 5x as many trees
	-- (combination with another noise in original code)
}

minetest.register_decoration({
	deco_type = "simple",
	place_on = {"default:dirt"},

	-- Papyrus is part of the tree placing code in 0.3, which tries to place
	-- a certain random amount of trees in a mapblock. This maps to the current
	-- deco mechanism very well.
	sidelen = 16,
	noise_params = np_tree_amount,

	y_min = water_level - 1,
	y_max = water_level - 1,

	decoration = "default:papyrus",
	height = 2,
	height_max = 3,

	-- need this to replace water
	flags = "force_placement",
})

minetest.register_decoration({
	deco_type = "simple",
	place_on = {"default:sand"},

	-- same as above
	sidelen = 16,
	noise_params = np_tree_amount,

	y_min = water_level + 1,
	y_max = 4,

	decoration = "default:cactus",
	height = 3,
})

-- TODO junglegrass can sit on top of cacti, consider emulating that

--
-- Custom stuff
--

local np_crumblyness = {
	offset = 0,
	scale = 1, -- = noise_scale
	spread = vector.new(20, 20, 20), -- = pos_scale
	seed = 34413,
	octaves = 3,
	persistence = 1.3,
	lacunarity = 2, -- hardcoded in noise.cpp
}

local np_wetness = {
	offset = 0,
	scale = 1,
	spread = vector.new(40, 40, 40),
	seed = 32474,
	octaves = 4,
	persistence = 1.1,
	lacunarity = 2,
}

local np_clay = {
	offset = 0.5,
	scale = 1,
	spread = vector.new(500, 500, 500),
	seed = 4321,
	octaves = 6,
	persistence = 0.95,
	lacunarity = 2,
	eased = false,
}

local function rand_pos(self, a, b)
	return self.rand:next(a.x+1, b.x-1), self.rand:next(a.y+1, b.y-1), self.rand:next(a.z+1, b.z-1)
end

local function place_some(self, sparseness, x, y, z, content)
	for idx in self.va:iter(x-1, y-1, z-1, x+1, y+1, z+1) do
		if self.data[idx] == self.c_stone and self.rand:next() % sparseness == 0 then
			self.data[idx] = content
		end
	end
end

local function perlin_3d_buf(self, np, buffer)
	-- get map with same dimensions as vmanip area so indexes can be reused
	local map = minetest.get_perlin_map(np, self.va:getExtent())
	return map:get_3d_map_flat(self.va.MinEdge, buffer)
end

local function fix_temple(self, cpos, wetness)
	-- Mapgenv6 has generated a desert temple room, great!
	-- Except we don't like that, desert temples weren't in 0.3.
	-- The best we can do here is make an attempt at changing them to at least
	-- resemble normal dungeons, which is what we'll do here.

	-- try to determine room dimensions, walls are stone:
	local d = {}
	for i, dir in ipairs(FIVE_DIRS) do
		local tmp = {}
		for off = -1, 1 do
			local start = vector.offset(cpos,
				i > 2 and off or 0, 0, i <= 2 and off or 0)
			table.insert(tmp, 1, 0)
			for j = 1, (i == 5 and 21 or 9) do
				local check = vector.add(start, vector.multiply(dir, j))
				if self.data[self.va:indexp(check)] == self.c_stone then
					break
				end
				tmp[1] = j
			end
		end
		table.sort(tmp)
		d[i] = tmp[2] -- median of three samples
	end

	-- (debug)
	--[[self.data[self.va:indexp(cpos)] = minetest.get_content_id("default:torch")
	for i, off in ipairs(d) do
		local tmp = vector.add(cpos, vector.multiply(FIVE_DIRS[i], off))
		self.data[self.va:indexp(tmp)] = minetest.get_content_id("default:sign_wall")
		minetest.get_meta(tmp):set_string("infotext", tostring(i))
	end--]]

	-- now turn all stone to cobble
	local rmin = vector.new(cpos.x - d[1] - 1, cpos.y        - 1, cpos.z - d[3] - 1)
	local rmax = vector.new(cpos.x + d[2] + 1, cpos.y + d[5] + 1, cpos.z + d[4] + 1)
	local c_cobble = minetest.get_content_id("default:cobble")
	local c_mossycobble = minetest.get_content_id("default:mossycobble")
	for idx in self.va:iterp(rmin, rmax) do
		if self.data[idx] == self.c_stone then
			local v = self.rand:next(0, 40) / 10 - 2
			self.data[idx] = (v < wetness[idx]/3) and c_mossycobble or c_cobble
		end
	end
end

local function make_nc(self, ncrandom, minp, maxp)
	local c_nc = minetest.get_content_id("default:nyancat")
	local c_nc_rb = minetest.get_content_id("default:nyancat_rainbow")
	local dir, facedir_i = vector.zero(), 0
	local r = ncrandom:next(0, 3)
	if r == 0 then
		dir.x = 1
		facedir_i = 3
	elseif r == 1 then
		dir.x = -1
		facedir_i = 1
	elseif r == 2 then
		dir.z = 1
		facedir_i = 2
	else
		dir.z = -1
	end
	local ex = vector.subtract(maxp, minp)
	local p = vector.offset(minp, ncrandom:next(0, ex.x-1),
		ncrandom:next(0, ex.y-1), ncrandom:next(0, ex.z-1))

	-- this sets param2 without needing to retrieve the entire buffer
	self.vm:set_node_at(p, { name = "air", param2 = facedir_i })
	self.data[self.va:indexp(p)] = c_nc
	local length = ncrandom:next(3, 15)
	for j = 1, length do
		p = vector.subtract(p, dir)
		self.data[self.va:indexp(p)] = c_nc_rb
	end
end

local cached_buf1 = {}
local cached_buf2 = {}
local cached_buf3 = {}
local cached_buf4 = {}

default.on_generated = function(minp, maxp, blockseed)
	if minp.y >= 100 then
		-- high in the air there's nothing, skip
		return
	end

	local self = {
		rand = PseudoRandom(blockseed),

		--va = VoxelArea,
		--vm = VoxelManip,
		data = cached_buf1,

		c_stone = minetest.get_content_id("default:stone")
	}
	do
		local vm, emin, emax = minetest.get_mapgen_object("voxelmanip")
		self.vm = vm
		self.va = VoxelArea:new({MinEdge=emin, MaxEdge=emax})
		self.vm:get_data(self.data)
	end

	local x, y, z
	local amount
	local crumblyness = perlin_3d_buf(self, np_crumblyness, cached_buf2)
	local wetness = perlin_3d_buf(self, np_wetness, cached_buf3)
	local c_coal = minetest.get_content_id("default:coalstone")
	local c_iron = minetest.get_content_id("default:ironstone")

	-- Before we do anything else: fix desert temples
	local gennotify = minetest.get_mapgen_object("gennotify")
	if gennotify.temple then
		for _, pos in ipairs(gennotify.temple) do
			fix_temple(self, pos, wetness)
		end
	end

	-- Mese
	local c_mese = minetest.get_content_id("default:mese")
	-- do this in slices to improve distribution accuracy
	for ii = 0, chunksize - 1 do
		local sminp = vector.offset(minp, 0, ii * 16, 0)
		local smaxp = vector.new(maxp.x, sminp.y + 15, maxp.z)
		-- assume ground level is at zero which simplifies this a lot
		local approx_ground_depth = -(sminp.y + smaxp.y) / 2
		amount = approx_ground_depth / 4
		amount = amount * (chunksize * chunksize)
		for n = 1, amount do
			if self.rand:next() % 50 == 0 then
				x, y, z = rand_pos(self, sminp, smaxp)
				place_some(self, 8, x, y, z, c_mese)
			end
		end
	end

	-- Minerals
	amount = self.rand:next(0, 15)
	amount = 20 * (amount*amount*amount) / 1000
	amount = amount * chunksize_c
	for n = 1, amount do
		x, y, z = rand_pos(self, minp, maxp)
		local mineral
		local idx = self.va:index(x, y+5, z)
		if crumblyness[idx] < -0.1 then
			mineral = c_coal
		elseif wetness[idx] > 0 then
			mineral = c_iron
		end
		if mineral ~= nil then
			place_some(self, 6, x, y, z, mineral)
		end
	end

	-- More coal
	local coal_amount = 30
	for ii = 1, chunksize_c do
		if self.rand:next() % math.floor(60 / coal_amount) == 0 then
			amount = self.rand:next(0, 15)
			amount = coal_amount * (amount*amount*amount) / 1000
			for n = 1, amount do
				x, y, z = rand_pos(self, minp, maxp)
				place_some(self, 8, x, y, z, c_coal)
			end
		end
	end

	-- More iron
	local iron_amount = 8
	for ii = 1, chunksize_c do
		if self.rand:next() % math.floor(60 / iron_amount) == 0 then
			amount = self.rand:next(0, 15)
			amount = iron_amount * (amount*amount*amount) / 1000
			for n = 1, amount do
				x, y, z = rand_pos(self, minp, maxp)
				place_some(self, 8, x, y, z, c_iron)
			end
		end
	end

	-- Gravel
	-- mgv6 takes care of sand and mud already and generates way
	-- less than 0.3 would have but we don't have a say in that.
	local c_gravel = minetest.get_content_id("default:gravel")
	for x = minp.x, maxp.x do
	for z = minp.z, maxp.z do
		for idx in self.va:iter(x, minp.y, z, x, maxp.y, z) do
			if self.data[idx] == self.c_stone then
				if crumblyness[idx] <= 1.3 and crumblyness[idx] > 0.7 and wetness[idx] < -0.6 then
					self.data[idx] = c_gravel
				end
			end
		end
	end
	end

	-- Generating dungeons are left up to the mapgen

	-- Nyancats
	local ncrandom = PseudoRandom(blockseed+9324342)
	-- same slice method here so they don't inadvertently appear above ground
	for ii = 0, chunksize - 1 do
		local sminp = vector.offset(minp, 0, ii * 16, 0)
		local smaxp = vector.new(maxp.x, sminp.y + 15, maxp.z)
		if sminp.y <= -3 then
			for ii = 1, (chunksize * chunksize) do
				if ncrandom:next(0, 1000) == 0 then
					make_nc(self, ncrandom, sminp, smaxp)
				end
			end
		end
	end

	-- Clay
	-- The condition for clay is as follows:
	-- (0, 1 or 2 nodes below water level) and (at the surface or one node deep)
	-- and (where sand is) and (noise comparison suceeds)
	local c_sand = minetest.get_content_id("default:sand")
	local c_clay = minetest.get_content_id("default:clay")
	local c_water = minetest.get_content_id("default:water_source")
	if minp.y <= water_level-2 and water_level+1 <= maxp.y then
		local claynoise = minetest.get_perlin_map(np_clay,
			{x=maxp.x - minp.x + 1, y=maxp.z - minp.z + 1}):get_2d_map_flat(
			{x=minp.x, y=minp.z}, cached_buf4)
		local stride = maxp.x - minp.x + 1
		--
		local idx
		local depth, val
		for x = minp.x, maxp.x do
		for z = minp.z, maxp.z do
			depth = 0
			-- y+1 to detect surface
			for y = water_level + 1, water_level - 2, -1 do
				idx = self.va:index(x, y, z)
				if y <= water_level and depth <= 1 and self.data[idx] == c_sand then
					val = claynoise[(z - minp.z) * stride + (x - minp.x) + 1]
					if val > 0 and val < (depth == 1 and 0.12 or 0.04) then
						self.data[idx] = c_clay
					end
				end
				if depth > 0 and self.data[idx] ~= core.CONTENT_AIR and self.data[idx] ~= c_water then
					depth = depth + 1
				end
			end
		end
		end
	end

	self.vm:set_data(self.data)
	self.vm:write_to_map()
end

-- It's possible someone would want ores to be generated in
-- a singlenode map, but the chance is very slim. So leave it alone.
if minetest.get_mapgen_setting("mg_name") ~= "singlenode" then
	minetest.register_on_generated(default.on_generated)
	minetest.set_gen_notify({temple = true})
end

-- for mapgen debugging
if false then
	minetest.override_item("default:stone", { drawtype = "airlike" })
	local hl = {"coalstone", "ironstone", "mese", "clay", "gravel", "nyancat", "nyancat_rainbow"}
	for _, s in ipairs(hl) do
		minetest.override_item("default:" .. s, {
			paramtype = "light",
			light_source = 8,
		})
	end
	minetest.register_on_newplayer(function(player)
		player:get_inventory():add_item("main", "default:pick_mese")
	end)
end


-- MaterialItems are equivalent to nodes and converted by the engine already
-- these two just don't match our internal naming:
minetest.register_alias("default:stone_with_coal", "default:coalstone")
minetest.register_alias("default:iron", "default:ironstone")

-- CraftItems and ToolItems are just read with their name as-is, so we need aliases for them
minetest.register_alias("Stick", "default:stick")
minetest.register_alias("paper", "default:paper")
minetest.register_alias("book", "default:book")
minetest.register_alias("lump_of_coal", "default:lump_of_coal")
minetest.register_alias("lump_of_iron", "default:lump_of_iron")
minetest.register_alias("lump_of_clay", "default:lump_of_clay")
minetest.register_alias("steel_ingot", "default:steel_ingot")
minetest.register_alias("clay_brick", "default:clay_brick")
minetest.register_alias("rat", "default:rat")
minetest.register_alias("cooked_rat", "default:cooked_rat")
minetest.register_alias("scorched_stuff", "default:scorched_stuff")
minetest.register_alias("firefly", "default:firefly")
minetest.register_alias("apple_iron", "default:apple_iron")

minetest.register_alias("WPick", "default:pick_wood")
minetest.register_alias("STPick", "default:pick_stone")
minetest.register_alias("SteelPick", "default:pick_steel")
minetest.register_alias("MesePick", "default:pick_mese")
minetest.register_alias("WShovel", "default:shovel_wood")
minetest.register_alias("STShovel", "default:shovel_stone")
minetest.register_alias("SteelShovel", "default:shovel_steel")
minetest.register_alias("WAxe", "default:axe_wood")
minetest.register_alias("STAxe", "default:axe_stone")
minetest.register_alias("SteelAxe", "default:axe_steel")
minetest.register_alias("WSword", "default:sword_wood")
minetest.register_alias("STSword", "default:sword_stone")
minetest.register_alias("SteelSword", "default:sword_steel")

-- Original references:
-- how it works https://github.com/minetest/minetest/blob/stable-0.3/src/content_sao.cpp
-- how it looks https://github.com/minetest/minetest/blob/stable-0.3/src/content_cao.cpp

--
-- helpers
--

assert(minetest.has_feature("object_step_has_moveresult"))

local gravity = tonumber(minetest.settings:get("movement_gravity")) or 9.81

local function limit_interval(self, prop, dtime, wanted_interval)
	self[prop] = self[prop] + dtime
	if self[prop] < wanted_interval then
		return false
	end
	self[prop] = self[prop] - wanted_interval
	return true
end

-- Y is copied, X and Z change is limited
local function accelerate_xz(vel, target_vel, max_increase)
	local d_wanted = vector.subtract(target_vel, vel)
	d_wanted.y = 0
	local dl = vector.length(d_wanted)
	dl = math.min(dl, max_increase)
	local d = vector.multiply(vector.normalize(d_wanted), dl)
	return vector.new(vel.x + d.x, target_vel.y, vel.z + d.z)
end

local function distance_xz(a, b)
	local x = a.x - b.x
	local z = a.z - b.z
	return math.sqrt(x * x + z * z)
end

local function checkFreePosition(p0, size)
	local nodes = minetest.find_nodes_in_area(p0,
		vector.add(vector.add(p0, size), -1), "air", true)
	if not nodes.air then
		return false
	end
	return #nodes.air == size.x * size.y * size.z
end

local function checkWalkablePosition(p0)
	local node = minetest.get_node(vector.offset(p0, 0, -1, 0))
	return node.name ~= "air"
end

local function checkFreeAndWalkablePosition(p0, size)
	return checkFreePosition(p0, size) and checkWalkablePosition(p0)
end

local function explodeSquare(p0, size)
	if default.modernize.sounds then
		minetest.sound_play("explode", {
			pos = p0,
		}, true)
	end
	-- FIXME: callbacks / indestructability?
	local positions = {}
	for dx = 0, size.x - 1 do
	for dy = 0, size.y - 1 do
	for dz = 0, size.z - 1 do
		positions[#positions+1] = vector.offset(p0, dx, dy, dz)
	end
	end
	end
	minetest.bulk_set_node(positions, {name="air"})
end

--
-- ItemSAO
--

if not default.modernize.new_item_entity then
	minetest.log("warning", "old ItemSAO unimplemented")
end

--
-- RatSAO
--

local RatSAO = {
	initial_properties = {
		physical = true,
		collide_with_objects = false,
		collisionbox = {-1/3, 0, -1/3, 1/3, 2/3, 1/3},
		selectionbox = {-1/3, 0, -1/3, 1/3, 1/2, 1/3},
		visual = "mesh",
		mesh = "rat.obj",
		textures = {"rat.png"},
		backface_culling = false,
	},

	is_active = false,
	inactive_interval = 0,
	oldpos = vector.zero(),
	counter1 = 0,
	counter2 = 0,
	sound_timer = 0,
}

function RatSAO:on_activate(staticdata, dtime_s)
	self.object:set_yaw(math.random(0, 6))
	self.object:set_acceleration(vector.new(0, -gravity, 0))
	self.object:set_armor_groups({punch_operable=1})
end

function RatSAO:on_step(dtime, moveresult)
	if not self.is_active then
		-- FIXME physics are actually turned off if inactive
		if not limit_interval(self, "inactive_interval", dtime, 0.5) then
			return
		end
	end

	-- Move around if some player is close
	local pos = self.object:get_pos()
	self.is_active = false
	for _, player in ipairs(minetest.get_connected_players()) do
		if vector.distance(player:get_pos(), pos) < 10 then
			self.is_active = true
		end
	end

	local vel = self.object:get_velocity()
	if not self.is_active then
		vel.x = 0
		vel.z = 0
	else
		-- Move around
		local yaw = self.object:get_yaw()
		local dir = vector.new(math.cos(yaw), 0, math.sin(yaw))
		local speed = 2
		vel.x = speed * dir.x
		vel.z = speed * dir.z

		if moveresult.touching_ground and vector.distance(self.oldpos, pos)
			< dtime * speed / 2 then
			self.counter1 = self.counter1 - dtime
			if self.counter1 < 0 then
				self.counter1 = self.counter1 + 1
				vel.y = 5
			end
		end

		self.counter2 = self.counter2 - dtime
		if self.counter2 < 0 then
			self.counter2 = self.counter2 + math.random(0, 300) / 100
			self.object:set_yaw(yaw + math.random(-100, 100) / 100 * math.pi)
		end

		self.sound_timer = self.sound_timer - dtime
		if self.sound_timer < 0 then
			if moveresult.touching_ground and default.modernize.sounds then
				minetest.sound_play("rat", {
					pos = pos,
				}, true)
			end
			self.sound_timer = self.sound_timer + 0.1 * math.random(40, 70)
		end
	end
	self.object:set_velocity(vel)

	self.oldpos = pos
end

function RatSAO:on_punch(hitter)
	local item = "default:rat"
	minetest.log("action", hitter:get_player_name() .. " picked up " .. item)
	if not minetest.is_creative_enabled(hitter:get_player_name()) then
		hitter:get_inventory():add_item("main", item)
	end
	self.object:remove()
end

minetest.register_entity("default:rat", RatSAO)

--
-- Oerkki1SAO
--

local Oerkki1SAO = {
	initial_properties = {
		hp_max = 20,
		physical = true,
		collide_with_objects = false,
		collisionbox = {-1/3, 0, -1/3, 1/3, 5/3, 1/3},
		selectionbox = {-1/3, 0, -1/3, 1/3, 2, 1/3},
		visual = "mesh",
		mesh = "oerkki1.obj",
		textures = {"oerkki1.png"},
		backface_culling = false,
		damage_texture_modifier = "^oerkki1_damaged.png", -- we're lucky this works
	},

	is_active = false,
	inactive_interval = 0,
	oldpos = vector.zero(),
	counter1 = 0,
	counter2 = 0,
	age = 0,
	after_jump_timer = 0,
	attack_interval = 0,
	is_hidden = false,
}

function Oerkki1SAO:on_activate(staticdata, dtime_s)
	if core.settings:get("only_peaceful_mobs") then
		self.object:remove()
		return
	end

	self.object:set_acceleration(vector.new(0, -gravity, 0))
	self.object:set_armor_groups({brittle=100})
end

function Oerkki1SAO:on_step(dtime, moveresult)
	if not self.is_active then
		-- FIXME physics are actually turned off if inactive
		if not limit_interval(self, "inactive_interval", dtime, 0.5) then
			return
		end
	end

	self.age = self.age + dtime
	if self.age > 900 then
		self.object:remove()
		return
	end

	self.after_jump_timer = self.after_jump_timer - dtime

	-- Move around if some player is close
	local pos = self.object:get_pos()
	local player_is_close = false
	local player_is_too_close = false
	local near_player_pos
	for _, player in ipairs(minetest.get_connected_players()) do
		local dist = vector.distance(player:get_pos(), pos)
		if dist < 0.6 then
			if not default.modernize.disable_oerkki_delete then
				self.object:remove()
				return
			end
			player_is_too_close = true
			near_player_pos = player:get_pos()
		elseif dist < 15 and not player_is_too_close then
			player_is_close = true
			near_player_pos = player:get_pos()
		end
	end

	self.is_active = player_is_close

	local vel = self.object:get_velocity()
	local target_vel = vector.new(vel)
	if not player_is_close then
		target_vel = vector.zero()
	else
		-- Move around
		local ndir = vector.subtract(near_player_pos, pos)
		ndir.y = 0
		ndir = vector.normalize(ndir)

		local yaw = self.object:get_yaw()
		local nyaw = math.atan2(ndir.z, ndir.x)
		if nyaw < yaw - math.pi then
			nyaw = nyaw + 2 * math.pi
		elseif nyaw > yaw + math.pi then
			nyaw = nyaw - 2 * math.pi
		end
		self.object:set_yaw(0.95*yaw + 0.05*nyaw)
		yaw = nil

		local speed = 2
		if (moveresult.touching_ground or self.after_jump_timer > 0) and not player_is_too_close then
			yaw = self.object:get_yaw()
			local dir = vector.new(math.cos(yaw), 0, math.sin(yaw))
			target_vel.x = speed * dir.x
			target_vel.z = speed * dir.z
		end

		if moveresult.touching_ground and vector.distance(self.oldpos, pos)
			< dtime * speed / 2 then
			self.counter1 = self.counter1 - dtime
			if self.counter1 < 0 then
				self.counter1 = self.counter1 + 0.2
				-- Jump
				target_vel.y = 5
				self.after_jump_timer = 1
			end
		end

		self.counter2 = self.counter2 - dtime
		if self.counter2 < 0 then
			self.counter2 = self.counter2 + math.random(0, 300) / 100
			yaw = self.object:get_yaw()
			self.object:set_yaw(yaw + math.random(-100, 100) / 200 * math.pi)
		end

		-- Damage close players
		local once = true
		for _, player in ipairs(minetest.get_connected_players()) do
			local playerpos = player:get_pos()
			if math.abs(pos.y - playerpos.y) < 1.5 and
				distance_xz(pos, playerpos) < 1.5 then
				if once and not limit_interval(self, "attack_interval", dtime, 0.5) then
					break
				end
				once = false
				player:set_hp(player:get_hp() - 2)
			end
		end

		-- Disappear at low light levels
		local hidden = minetest.get_node_light(vector.round(pos)) <= 2
		if self.is_hidden ~= hidden then
			self.object:set_properties({is_visible = not hidden})
			self.is_hidden = hidden
		end
	end

	if vector.distance(vel, target_vel) > 4 or player_is_too_close then
		self.object:set_velocity(accelerate_xz(vel, target_vel, dtime * 8))
	else
		self.object:set_velocity(accelerate_xz(vel, target_vel, dtime * 4))
	end

	self.oldpos = pos

	-- Do collision damage
	if moveresult.collides and #moveresult.collisions > 0 then
		local tolerance = 30
		local factor = 0.5
		local speed_diff = vector.subtract(moveresult.collisions[1].old_velocity,
			moveresult.collisions[#moveresult.collisions].new_velocity)
		-- Increase effect in X and Z
		speed_diff.x = speed_diff.x * 2
		speed_diff.z = speed_diff.z * 2
		local l = vector.length(speed_diff)
		if l > tolerance then
			local damage = math.round((l - tolerance) * factor)
			self.object:set_hp(self.object:get_hp() - damage)
		end
	end
end

function Oerkki1SAO:on_punch(hitter, time_from_last_punch)
	if (time_from_last_punch or 0) <= 0.5 then
		return true
	end

	local dir = vector.subtract(self.object:get_pos(), hitter:get_pos())
	dir = vector.normalize(dir)
	self.object:set_velocity(vector.add(self.object:get_velocity(),
		vector.multiply(dir, 12)))
end

minetest.register_entity("default:oerkki1", Oerkki1SAO)

--
-- FireflySAO
--

local FireflySAO = {
	initial_properties = {
		physical = true,
		collide_with_objects = false,
		collisionbox = {-1/3, -2/3, -1/3, 1/3, 4/3, 1/3},
		selectionbox = {-1/3, 0, -1/3, 1/3, 1/2, 1/3},
		visual = "mesh",
		mesh = "firefly.obj",
		textures = {"firefly.png"},
		backface_culling = false,
		glow = minetest.LIGHT_MAX,
	},

	is_active = false,
	inactive_interval = 0,
	oldpos = vector.zero(),
	counter1 = 0,
	counter2 = 0,
}

function FireflySAO:on_activate(staticdata, dtime_s)
	-- Apply (less) gravity
	self.object:set_acceleration(vector.new(0, -3, 0))
	self.object:set_armor_groups({punch_operable=1})
end

function FireflySAO:on_step(dtime, moveresult)
	if not self.is_active then
		-- FIXME physics are actually turned off if inactive
		if not limit_interval(self, "inactive_interval", dtime, 0.5) then
			return
		end
	end

	-- Move around if some player is close
	local pos = self.object:get_pos()
	self.is_active = false
	for _, player in ipairs(minetest.get_connected_players()) do
		if vector.distance(player:get_pos(), pos) < 10 then
			self.is_active = true
		end
	end

	local vel = self.object:get_velocity()
	if not self.is_active then
		vel.x = 0
		vel.z = 0
	else
		-- Move around
		local yaw = self.object:get_yaw()
		local dir = vector.new(math.cos(yaw), 0, math.sin(yaw))
		local speed = 0.5
		vel.x = speed * dir.x
		vel.z = speed * dir.z

		if moveresult.touching_ground and vector.distance(self.oldpos, pos)
			< dtime * speed / 2 then
			self.counter1 = self.counter1 - dtime
			if self.counter1 < 0 then
				self.counter1 = self.counter1 + 1
				vel.y = 5
			end
		end

		self.counter2 = self.counter2 - dtime
		if self.counter2 < 0 then
			self.counter2 = self.counter2 + math.random(0, 300) / 100
			self.object:set_yaw(yaw + math.random(-100, 100) / 100 * math.pi)
		end
	end
	self.object:set_velocity(vel)

	self.oldpos = pos
end

function FireflySAO:on_punch(hitter)
	local item = "default:firefly"
	minetest.log("action", hitter:get_player_name() .. " picked up " .. item)
	if not minetest.is_creative_enabled(hitter:get_player_name()) then
		hitter:get_inventory():add_item("main", item)
	end
	self.object:remove()
end

minetest.register_entity("default:firefly", FireflySAO)

--
-- MobV2SAO
--

local MobV2SAO = {
	initial_properties = {
		physical = false,
		visual = "sprite",
		damage_texture_modifier = "^[colorize:#ff0000",
	},

	props = nil,
	random_disturb_timer = 0,
	disturbing_player = "",
	disturb_timer = 0,
	falling = false,
	shooting_timer = 0,
	shooting = false,
	shoot_reload_timer = 0,
	shoot_y = 0, -- not the same as props.shoot_y
	next_pos = nil,
	walk_around_timer = 0,
	walk_around = false,
	--
	sprite_type = "",
	sprite_y = 0,
	walking = false,
	walking_unset_timer = 0,
	last_sprite_row = -1,
	bright_shooting = false,
	player_hit_timer = 0,
}

local MobV2SAO_props = { -- defaults
	is_peaceful = false,
	move_type = "ground_nodes",
	age = 0,
	die_age = -1,
	size = {x = 1, y = 2},
	shoot_type = "fireball",
	shoot_y = 0,
	mindless_rage = false,
	--
	looks = "dummy_default",
	player_hit_damage = 0,
	player_hit_distance = 1.5,
	player_hit_interval = 1.5,
}

-- !(dx == 0 && dy == 0) && !(dx != 0 && dz != 0 && dy != 0)
local MobV2SAO_dps = {
	{x=-1,y=-1,z=0}, {x=-1,y=0,z=-1}, {x=-1,y=0,z=0},
	{x=-1,y=0,z=1},  {x=-1,y=1,z=0},  {x=0,y=-1,z=-1},
	{x=0,y=-1,z=0},  {x=0,y=-1,z=1},  {x=0,y=1,z=-1},
	{x=0,y=1,z=0},   {x=0,y=1,z=1},   {x=1,y=-1,z=0},
	{x=1,y=0,z=-1},  {x=1,y=0,z=0},   {x=1,y=0,z=1},
	{x=1,y=1,z=0}
}

default.spawn_mobv2 = function(pos, props)
	local staticdata = minetest.write_json(props, false)
	return minetest.add_entity(pos, "default:mobv2", staticdata)
end

default.get_mob_dungeon_master = function()
	return {
		looks = "dungeon_master",
		hp = 30,
		shoot_type = "fireball",
		shoot_y = 0.7,
		player_hit_damage = 1,
		player_hit_distance = 1,
		player_hit_interval = 0.5,
		mindless_rage = math.random(0, 100) == 0,
	}
end

function MobV2SAO:getPos()
	-- Because we can't do offset rendering we move the position higher by the
	-- sprite_y and subtract it for internal calculations
	return vector.offset(self.object:get_pos(), 0, -self.sprite_y, 0)
end

function MobV2SAO:setPos(pos)
	self.object:set_pos(vector.offset(pos, 0, self.sprite_y, 0))
end

function MobV2SAO:setLooks(looks)
	local selection_size = {x=0.4, y=0.4}
	local selection_y = 0
	local texture_name
	local sprite_size
	local lock_full_brightness = false
	local simple_anim_frames
	local simple_anim_frametime

	self.sprite_y = 0

	if looks == "dungeon_master" then
		texture_name = "dungeon_master.png"
		self.sprite_type = "humanoid_1"
		sprite_size = {x=2, y=3}
		self.sprite_y = 0.85
		selection_size = {x=0.4, y=2.6}
		selection_y = -0.4
	elseif looks == "fireball" then
		texture_name = "fireball.png"
		self.sprite_type = "simple"
		sprite_size = {x=1, y=1}
		simple_anim_frames = 3
		simple_anim_frametime = 0.1
		lock_full_brightness = true
	else
		texture_name = "stone.png"
		self.sprite_type = "simple"
		sprite_size = {x=1, y=1}
		simple_anim_frames = 3
		simple_anim_frametime = 0.333
	end

	--

	local toset = {
		textures = { texture_name .. "^[makealpha:128,0,0^[makealpha:128,128,0" },
		visual_size = sprite_size,
		selectionbox = {-selection_size.x, selection_y, -selection_size.x,
			selection_size.x, selection_size.y + selection_y, selection_size.x},
	}

	toset.selectionbox[2] = toset.selectionbox[2] - self.sprite_y
	toset.selectionbox[5] = toset.selectionbox[5] - self.sprite_y

	if self.sprite_type == "humanoid_1" then
		toset.spritediv = {x=6, y=5}
	elseif self.sprite_type == "simple" then
		toset.spritediv = {x=1, y=simple_anim_frames}
	end
	if lock_full_brightness then
		toset.glow = minetest.LIGHT_MAX
	end

	self.object:set_properties(toset)

	if self.sprite_type == "simple" then
		-- enable animation
		self.object:set_sprite({x=0, y=0}, simple_anim_frames, simple_anim_frametime)
	end
end

function MobV2SAO:on_activate(staticdata, dtime_s)
	self.disturb_timer = 10000

	self.props = table.copy(MobV2SAO_props)
	local my_props = minetest.parse_json(staticdata)
	assert(type(my_props) == "table")
	for k, v in pairs(my_props) do
		self.props[k] = v
	end
	if core.settings:get("only_peaceful_mobs") and not self.props.is_peaceful then
		self.object:remove()
		return
	end

	-- Only read on init, since the engine takes care of saving these normally
	if self.props.speed then
		self.object:set_velocity(self.props.speed)
		self.props.speed = nil
	end
	if self.props.hp then
		self.object:set_hp(self.props.hp)
		self.props.hp = nil
	end
	self:setLooks(self.props.looks)

	self.object:set_armor_groups({fleshy=100})
end

function MobV2SAO:get_staticdata()
	return minetest.write_json(self.props, false)
end

function MobV2SAO:on_death()
	minetest.log("action",
		string.format("A %s mob dies at %s",
		(self.props.is_peaceful and "peaceful" or "non-peaceful"),
		minetest.pos_to_string(vector.round(self:getPos()))
	))
end

function MobV2SAO:stepVisuals(dtime, pos)
	-- this code was in the CAO in 0.3 so encapsulated here

	if self.sprite_type == "humanoid_1" then
		local row = 0
		local frames, frametime = 1, 0
		if self.shooting then
			row = 3
		elseif self.walking then
			-- note: set only via timer so the animation isn't interrupted
			row = 1
			frames, frametime = 2, 0.5
		end
		if row ~= self.last_sprite_row then
			self.object:set_sprite({x=0, y=row}, frames, frametime, true)
			self.last_sprite_row = row
		end
	end

	-- Damage close players
	if self.props.player_hit_damage and self.player_hit_timer <= 0 then
		local any = false
		for _, player in ipairs(minetest.get_connected_players()) do
			local playerpos = player:get_pos()
			if math.abs(pos.y - playerpos.y) < self.props.player_hit_distance and
				distance_xz(pos, playerpos) < self.props.player_hit_distance then
				any = true
				player:set_hp(player:get_hp() - self.props.player_hit_damage)
			end
		end
		if any then
			self.player_hit_timer = self.props.player_hit_interval
		end
	end

	self.walking_unset_timer = self.walking_unset_timer + dtime
	if self.walking_unset_timer >= 1 then
		self.walking = false
	end

	if self.shooting ~= self.bright_shooting then
		self.object:set_properties({
			glow = self.shooting and minetest.LIGHT_MAX or 0,
		})
		self.bright_shooting = self.shooting
	end
end

function MobV2SAO:on_step(dtime, moveresult)
	self.props.age = self.props.age + dtime
	if self.props.die_age >= 0 and self.props.age >= self.props.die_age then
		self.object:remove()
		return
	end

	local pos = self:getPos()

	self.random_disturb_timer = self.random_disturb_timer + dtime
	if self.random_disturb_timer >= 5 then
		self.random_disturb_timer = 0
		for _, player in ipairs(minetest.get_connected_players()) do
			if vector.distance(player:get_pos(), pos) < 16 then
				if math.random(0, 3) == 0 then
					minetest.log("action",
						string.format("Mob at %s got randomly disturbed by %s",
						minetest.pos_to_string(vector.round(pos)),
						player:get_player_name()
					))
					self.disturbing_player = player:get_player_name()
					self.disturb_timer = 0
					break
				end
			end
		end
	end

	local d_player_distance, d_player_norm, d_player_dir
	if self.disturbing_player ~= "" then
		local player = minetest.get_player_by_name(self.disturbing_player)
		local offset = vector.subtract(player:get_pos(), pos)
		d_player_distance = vector.length(offset)
		d_player_norm = vector.normalize(offset)
		d_player_dir = math.atan2(d_player_norm.z, d_player_norm.x)
	end

	self.disturb_timer = self.disturb_timer + dtime

	if not self.falling then
		self.shooting_timer = self.shooting_timer - dtime
		if self.shooting_timer <= 0 and self.shooting then
			self.shooting = false

			if self.props.shoot_type == "fireball" then
				local yaw = self.object:get_yaw()
				local dir = vector.new(math.cos(yaw), 0, math.sin(yaw))
				dir.y = self.shoot_y
				dir = vector.normalize(dir)
				local speed = vector.multiply(dir, 10)
				local shoot_pos = vector.offset(pos, 0, self.props.shoot_y, 0)
				minetest.log("info", "Mob shooting fireball from " ..
					minetest.pos_to_string(shoot_pos) .. " at speed " ..
					minetest.pos_to_string(speed))
				if default.modernize.sounds then
					minetest.sound_play("fireball", {
						pos = shoot_pos,
					}, true)
				end
				default.spawn_mobv2(shoot_pos, {
					looks = "fireball",
					speed = speed,
					die_age = 5,
					move_type = "constant_speed",
					hp = 1000,
					player_hit_damage = 9,
					player_hit_distance = 2,
					player_hit_interval = 1,
				})
			end
		end

		self.shoot_reload_timer = self.shoot_reload_timer + dtime

		local reload_time = self.disturb_timer < 15 and 3 or 15

		local shoot_without_player = self.props.mindless_rage == true

		if not self.shooting and self.shoot_reload_timer >= reload_time and
			not self.next_pos and
			(self.disturb_timer < 60 or shoot_without_player) then
			if self.disturb_timer < 60 and d_player_norm and
				d_player_distance < 16 and math.abs(d_player_norm.y) < 0.8 then
				self.object:set_yaw(d_player_dir)
				self.shoot_y = d_player_norm.y
			else
				self.shoot_y = math.random(-30, 10) * 0.01
			end
			self.shoot_reload_timer = 0
			self.shooting = true
			self.shooting_timer = 1.5
		end
	end

	if self.props.move_type == "ground_nodes" then
		if not self.shooting then
			self.walk_around_timer = self.walk_around_timer - dtime
			if self.walk_around_timer <= 0 then
				self.walk_around = not self.walk_around
				if self.walk_around then
					self.walk_around_timer = 0.1 * math.random(10, 50)
				else
					self.walk_around_timer = 0.1 * math.random(30, 70)
				end
			end
		end

		-- Move
		if self.next_pos then
			local diff = vector.subtract(self.next_pos, pos)
			self.object:set_yaw(math.atan2(diff.z, diff.x))

			local dir = vector.normalize(diff)
			local speed = self.falling and 3 or 0.5
			dir = vector.multiply(dir, dtime * speed)
			local arrived = false
			if vector.length(dir) > vector.length(diff) then
				dir = diff
				arrived = true
			end
			pos = vector.add(pos, dir)
			self:setPos(pos)

			if vector.distance(pos, self.next_pos) < 0.1 or arrived then
				self.next_pos = nil
			end
		end

		if self.next_pos and not self.walking then -- if we moved any
			self.walking = true
			self.walking_unset_timer = 0
		end

		local pos_i = vector.round(pos)
		local size_blocks = vector.new(math.round(self.props.size.x),
			math.round(self.props.size.y), math.round(self.props.size.x))
		local pos_size_off = vector.zero()
		if self.props.size.x >= 2.5 then
			pos_size_off.x = -1
			pos_size_off.y = -1
		end

		if not self.next_pos then
			-- Check whether to drop down
			local tmp = vector.offset(vector.add(pos_i, pos_size_off), 0, -1, 0)
			if checkFreePosition(tmp, size_blocks) then
				self.next_pos = pos_i:offset(0, -1, 0)
				self.falling = true
			else
				self.falling = false
			end
		end

		if self.walk_around and not self.next_pos then
			-- Find some position where to go next
			table.shuffle(MobV2SAO_dps)
			for _, dps in ipairs(MobV2SAO_dps) do
				local p = vector.add(pos_i, dps)
				if checkFreeAndWalkablePosition(vector.add(p, pos_size_off), size_blocks) then
					self.next_pos = p
					break
				end
			end
		end
	elseif self.props.move_type == "constant_speed" then
		local pos_i = vector.round(pos)
		local size_blocks = vector.new(math.round(self.props.size.x),
			math.round(self.props.size.y), math.round(self.props.size.x))
		local pos_size_off = vector.zero()
		if self.props.size.x >= 2.5 then
			pos_size_off.x = -1
			pos_size_off.y = -1
		end

		if not checkFreePosition(vector.add(pos_i, pos_size_off), size_blocks) then
			explodeSquare(pos_i, vector.new(3, 3, 3))
			self.object:remove()
			return
		end
	end

	self:stepVisuals(dtime, pos)
end

function MobV2SAO:on_punch(hitter, time_from_last_punch)
	if (time_from_last_punch or 0) <= 0.5 then
		return true
	end

	self.disturb_timer = 0
	self.disturbing_player = hitter:get_player_name()
	self.next_pos = nil -- Cancel moving immediately

	local dir = vector.subtract(self:getPos(), hitter:get_pos())
	dir = vector.normalize(dir)
	self.object:set_yaw(math.atan2(dir.z, dir.x) + math.pi)
	local new_pos = vector.add(self:getPos(), dir)
	do
		local pos_i = vector.round(new_pos)
		local size_blocks = vector.new(math.round(self.props.size.x),
			math.round(self.props.size.y), math.round(self.props.size.x))
		local pos_size_off = vector.zero()
		if self.props.size.x >= 2.5 then
			pos_size_off.x = -1
			pos_size_off.y = -1
		end
		if checkFreePosition(vector.add(pos_i, pos_size_off), size_blocks) then
			self:setPos(new_pos)
		end
	end
end

--function MobV2SAO:on_rightclick()
--	print(dump(self))
--end

minetest.register_entity("default:mobv2", MobV2SAO)