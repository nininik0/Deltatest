-- MaterialItems are equivalent to nodes and converted by the engine already
-- these two just don't match our internal naming:
minetest.register_alias("default:stone_with_coal", "default:coalstone")
minetest.register_alias("default:iron", "default:ironstone")

-- CraftItems and ToolItems are just read with their name as-is, so we need aliases for them
minetest.register_alias("Stick", "default:stick")
minetest.register_alias("paper", "default:paper")
minetest.register_alias("book", "default:book")
minetest.register_alias("lump_of_coal", "default:lump_of_coal")
minetest.register_alias("lump_of_iron", "default:lump_of_iron")
minetest.register_alias("lump_of_clay", "default:lump_of_clay")
minetest.register_alias("steel_ingot", "default:steel_ingot")
minetest.register_alias("clay_brick", "default:clay_brick")
minetest.register_alias("rat", "default:rat")
minetest.register_alias("cooked_rat", "default:cooked_rat")
minetest.register_alias("scorched_stuff", "default:scorched_stuff")
minetest.register_alias("firefly", "default:firefly")
minetest.register_alias("apple_iron", "default:apple_iron")

minetest.register_alias("WPick", "default:pick_wood")
minetest.register_alias("STPick", "default:pick_stone")
minetest.register_alias("SteelPick", "default:pick_steel")
minetest.register_alias("MesePick", "default:pick_mese")
minetest.register_alias("WShovel", "default:shovel_wood")
minetest.register_alias("STShovel", "default:shovel_stone")
minetest.register_alias("SteelShovel", "default:shovel_steel")
minetest.register_alias("WAxe", "default:axe_wood")
minetest.register_alias("STAxe", "default:axe_stone")
minetest.register_alias("SteelAxe", "default:axe_steel")
minetest.register_alias("WSword", "default:sword_wood")
minetest.register_alias("STSword", "default:sword_stone")
minetest.register_alias("SteelSword", "default:sword_steel")


-- Register Yellow Frame
minetest.register_node("default:yellow_frames", {
    description = "Yellow Frames",
    drawtype = "allfaces", -- Glass-like appearance with optional frame
    tiles = {"yellowframes.png"}, -- Main and detail textures
    paramtype = "light",
    sunlight_propagates = true,
    is_ground_content = false,
    groups = {wood = 3, oddly_breakable_by_hand = 3},
})

-- Register Blue Frame
minetest.register_node("default:blue_frames", {
    description = "Blue Frames",
    drawtype = "allfaces", -- Glass-like appearance with optional frame
    tiles = {"blueframes.png"}, -- Main and detail textures
    paramtype = "light",
    sunlight_propagates = true,
    is_ground_content = false,
    groups = {wood = 3, oddly_breakable_by_hand = 3},
})

-- Crafting Recipes
minetest.register_craft({
    output = "defaulr:yellow_frames 4",
    recipe = {
        {"default:glass", "woolmod:yellow_dye", "default:glass"},
        {"woolmod:yellow_dye", "default:glass", "woolmod:yellow_dye"},
        {"default:glass", "woolmod:yellow_dye", "default:glass"},
    }
})

minetest.register_craft({
    output = "default:blue_frames 4",
    recipe = {
        {"default:glass", "woolmod:blue_dye", "default:glass"},
        {"woolmod:blue_dye", "default:glass", "woolmod:blue_dye"},
        {"default:glass", "woolmod:blue_dye", "default:glass"},
    }
})