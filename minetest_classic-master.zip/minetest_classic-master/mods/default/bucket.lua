
-- Register the Compressed Gravel node
minetest.register_node("default:compressed_gravel", {
    description = "Compressed Gravel",
    tiles = {"compressedgravel.png"}, -- Replace with your texture
    groups = {dirt = 3},
    sounds = default.node_sound_gravel,
})

-- Register the crafting recipe for Compressed Gravel
minetest.register_craft({
    output = "default:compressed_gravel",
    recipe = {
        {"default:gravel", "default:gravel", "default:gravel"},
        {"default:gravel", "default:gravel", "default:gravel"},
        {"default:gravel", "default:gravel", "default:gravel"},
    }
})

-- Register crafting to revert Compressed Gravel back into 9 Gravel
minetest.register_craft({
    output = "default:gravel 9",
    recipe = {
        {"default:compressed_gravel"},
    }
})

-- Bucket: Punch liquid source or flowing liquid to collect it

minetest.register_tool("default:bucket", {
	description = "Bucket".."\n"..
		"Picks up liquid nodes",
	inventory_image = "bucket.png",
	stack_max = 1,
	liquids_pointable = true,
	groups = { disable_repair = 1 },
	on_use = function(itemstack, user, pointed_thing)
		-- Must be pointing to node
		if pointed_thing.type ~= "node" then
			return
		end
		-- Check if pointing to a liquid
		local n = minetest.get_node(pointed_thing.under)
		local def = minetest.registered_nodes[n.name]
		if def ~= nil and (def.liquidtype == "source" or def.liquidtype == "flowing") then
			minetest.add_node(pointed_thing.under, {name="air"})
			local inv = user:get_inventory()
			if inv then
				inv:add_item("main", ItemStack(n.name))
			end
		end
	end,
})



--
-- msg
--

	minetest.chat_send_all("warning", "YOU ARE PLAYING A FORBIDDEN MINETEST VERSION,PLEASE STOP USE IMMEDIATELY")


--
-- RatSAO
--
minetest.register_node("default:bricc", {
	description = "stone bricks",
	tiles = {"cobble_bricks.png"},
	groups = {stone = 2},
})

minetest.register_craft({
	output = "default:bricc",
	recipe = {{"default:brick", "default:stone"}}

})


minetest.register_node("default:dirt_block", {
	description = "2Dirt",
	tiles = {"dirt1.png"},
    groups = {plastic = 5},
})
minetest.register_node("default:stone_block", {
	description = "2Stone",
	tiles = {"stone1.png"},
    groups = {plastic = 5},
})
minetest.register_node("default:cobble2", {
	description = "2cobble",
	tiles = {"coobble.png"},
    groups = {plastic = 5},
})
minetest.register_node("default:grass_covered_dirt1_block", {
	description = "Grass Block",
	tiles = {"grass1.png", "dirt1.png", "grass_side1.png"},
    groups = {plastic = 5},
})
minetest.register_node("default:glass1", {
	description = "Glass",
	tiles = {"glass1.png"},
    drawtype = "allfaces",
    sunlight_propagates = true,
    paramtype = "light",
     -- TODO: Understand paramtype+use_texture_alpha...
	use_texture_alpha = minetest.features.use_texture_alpha_string_modes and "blend" or true,
    groups = {plastic = 5},
})
minetest.register_node("default:grass_block", {
	description = "2Block of Grass",
	tiles = {"grass1.png"},
    groups = {plastic = 5},
})
minetest.register_node("default:wooden", {
	description = "2Wood",
	tiles = {"minetestrpg_blocks_wood_v.png", "minetestrpg_blocks_wood_v.png", "minetestrpg_blocks_wood_h.png"},
    groups = {plastic = 5},
})
minetest.register_node("default:leaves1", {
	description = "2Leaves 1",
	tiles = {"minetestrpg_blocks_leaves1.png"},
    drawtype = "allfaces",
    sunlight_propagates = true,
    paramtype = "light",
    groups = {plastic = 5},
})
minetest.register_node("default:fake_sky", {
	description = "FakeSky",
	tiles = {"minetestrpg_blocks_fakesky.png"},
    sunlight_propagates = true,
    paramtype = "light",
    groups = {plastic = 5},
})
minetest.register_node("default:flag_blue", {
	description = "2D flag",
  visual_scale = 2.0,
	tiles = {"jw.png"},
    drawtype = "torchlike",
    sunlight_propagates = true,
    paramtype = "light",
    groups = {plastic = 5, dig_immediate = 3},
})

minetest.register_node("default:pattern_dark", {
	description = "Dark Pattern",
	tiles = {"grassland.png"},
    groups = {plastic = 5},
})

minetest.register_node("default:steelx", {
	description = ("X"),
	inventory_image = minetest.inventorycube("di.png"),
	wield_image = minetest.inventorycube("di.png"),
	tiles = {"di.png"},
	groups = {dig_mese=1},
	drawtype = "allfaces",
  paramtype = "light",
	air_equivalent = true,
	sunlight_propagates = true,
})

minetest.register_node("default:dee", {
	description = "Wood Tile",
	tiles = {"c.png"},
	groups = {wood = 2},
})

minetest.register_craft({
	output = "default:dee",
	recipe = {{"default:stick", "default:wood"}}
})

minetest.register_node("default:is", {
	description = "Patterned block",
	tiles = {"is.png"},
	groups = {stone = 2},
})

minetest.register_craft({
	output = "infinite_wood:is 2",
	recipe = {{"default:s", "default:mese"}}
})

minetest.register_craft({
	output = "default:tree 8",
	recipe = {{"infinite_wood:fake_diamond", "infinite_wood:fake_diamond"}}
})

minetest.register_node("default:s", {
	description = "Jungle Wood",
	tiles = {"d.png"},
  groups = {wood = 1},
})

minetest.register_node("default:ooh", {
	description = "a",
	tiles = {"ooh.png"},
	groups = {dig_mese= 1},
})

minetest.register_craft({
	output = "default:s 4",
	recipe = {{"default:jungletree"}}
})

minetest.register_craft({
	output = "default:ooh",
	recipe = {{"default:s", "default:apple", "default:s"}}
})




-- Barriers
-- Red: bad portal
-- Pink: Unfilled frames
-- Blue: Unconnected
-- Gray: Fake portal

minetest.register_node("default:barrier1", {
	description = "Barrier",
	light_source = 1,
	paramtype = "light",
	tiles = {name = "barrier_pink.png"},
	--walkable = false,
	groups={plastic = 3},
})

minetest.register_node("default:barrier2", {
	description = "Barrier",
	light_source = 1,
	paramtype = "light",
groups={plastic = 3},
	tiles = {name = "barrier_red.png"},
	--walkable = false,
	groups={plastic = 3},
})

minetest.register_node("default:barrier3", {
	description = "Barrier",
	light_source = 1,
	paramtype = "light",
	tiles = {name = "barrier_gray.png"},
	--walkable = false,
	groups={plastic = 3},
})

minetest.register_node("default:barrier", {
	description = "Barrier",
	light_source = 1,
	paramtype = "light",
	tiles = {name = "barrier.png"},
	--walkable = false,
	diggable = false,
})


minetest.register_node("default:wall", {
	description = "Wall",
	tiles = {"wall.png"},
	--drawtype = "allfaces_optional",
	--use_texture_alpha = "blend",
})



minetest.register_node("default:frame", {
	description = "Frame",
	--paramtype = "light",
	light_source = 8,
	drawtype = "allfaces",
	use_texture_alpha = "blend",
	tiles = {"frame.png"},
	buildable_to = false,
})




local sound_def = {
    dig = "soundstuff_mono"
}

minetest.register_node("default:glowstone", {
    description="Glowstone",
    tiles={"stone.png"},
    sounds = sound_def,
    groups={plastic = 3},
    light_source = 10
})

minetest.register_node("default:pocket_sun", {
    description="Pocket Sun",
    tiles={"skybox2.png"},
    sounds = sound_def,
    groups={plastic =30},
    light_source = 14
})

minetest.register_node("default:wl", {
	description = ("Inll"),
	inventory_image = minetest.inventorycube("i.png"),
	wield_image = minetest.inventorycube("i.png"),
	tiles = {"i.png"},
	groups = {stone=1},
	drawtype = "allfaces_optional",
  paramtype = "light",
	air_equivalent = true,
	sunlight_propagates = true,
	on_blast = function()
  end,
})

minetest.register_node(":m1n3t3st", {
	description = "MINETEST SPECIFICATIONS BLOCK [ADMINS ONLY]",
	tiles = {"soundstuff_node.png^paintings_painting_11.png"},
	groups = {oddly_breakable_by_hand = 2},
})

minetest.register_craft({
	output = ":m1n3t3st",
	recipe = {{"default:tree", "air"}}
})

minetest.register_node("default:reinwood", {
	description = "Reinforced wood",
	tiles = {"wood_reinforced.png"},
	groups = {stone = 2},
})

minetest.register_craft({
	output = "default:reinwood 2",
	recipe = {{"default:wood", "default:stone"}}
})

minetest.register_craft({
	output = "default:tree 8",
	recipe = {{"default:stick", "default_jungletree"}}
})

minetest.register_tool("default:ADpick", {
	description = "pickaxe (admin)",
	inventory_image = "pick.png",
	tool_capabilities = {
		groupcaps={
			plastic = {maxlevel=12496, times = {0, 0, 0, 0, 0},dirt=3,wood=3,stone=3,cracky=3,choppy=3,snappy=3, oddly_breakable_by_hand = 3},
		},
		damage_groups = {fleshy=12496},
	},
	groups = {pickaxe = 1}
})


minetest.register_node("default:blackwindow", {
	description = ("black spherical window"),
	drawtype = "allfaces",
	paramtype = "light",
	tiles = { "low_air.png" },
  groups = { wood = 3 },
})

minetest.register_node("default:reinglass", {
	description = ("Reinforced glass"),
	inventory_image = minetest.inventorycube("invisible_wall.png"),
	wield_image = minetest.inventorycube("invisible_wall.png"),
	tiles = {"invisible_wall.png"},
	groups = {stone=1},
	drawtype = "glasslike",
  paramtype = "light",
	air_equivalent = true,
	sunlight_propagates = true,
	on_blast = function()
  end,
})


minetest.register_tool("default:digga",  {
	description = ("p1ck4x3"),
	inventory_image = "cartoonpick.png",
	tool_capabilities = {
		full_punch_intervall = 1.5,
		max_drop_level = 1,
		groupcaps = {
			easy = {
				uses = 100,
				maxlevel = 1,
				times = {[1]=0.6},
			},
		},
		damage_groups = {fleshy=1},
	},
})

  minetest.register_craft({
    type = "shaped",
    output = "default:reinglass 5",
    recipe = {
    {"","default:glass",""},
    {"default:glass","default:steel_ingot","default:glass"},
    {"","default:glass",""},
    },
  })

minetest.register_node("default:test", {
description = ("test"),
drawtype = "allfaces",
paramtype = "light",
tiles = { "test.png" },

groups = { plastic = 3 },
})



minetest.register_node("default:crusher", {
    description = "Crusher (not functional yet)",
    tiles = {
        "crusher_top.png",       -- Top
        "crusher_side.png",    -- Bottom
        "crusher_side.png",      -- Right side
        "crusher_side.png",      -- Left side
        "crusher_back.png",      -- Back
        "crusher_front.png"      -- Front
    },
    groups = {dig_mese = 1},
    sounds = default.node_sound_stone,
})




minetest.register_node("default:three_dots", {
description = ("..."),
drawtype = "allfaces",
paramtype = "wallmounted",
tiles = { "3dot.png" },

groups = { dig_immediate = 3 },
})

minetest.register_node("default:pat", {
description = ("pattern"),
drawtype = "allfaces",
paramtype = "wallmounted",
tiles = { "naw.png" },

groups = { dig_immediate = 3 },
})

minetest.register_node("default:err", {
description = ("72829372947257"),
drawtype = "allfaces",
paramtype = "wallmounted",
tiles = { "90.png" },

groups = { dig_immediate = 3 },
})

minetest.register_node("default:hiddenchest", {
	description = "Chest",
	tiles = { "stone.png" },
	paramtype2 = "facedir",
	legacy_facedir_simple = true,
	groups = { wood = 6 },
	sounds = default.node_sound.wood,
	on_construct = function(pos)
		local meta = minetest.get_meta(pos)
		meta:set_string("formspec", "size[8,9]"..
			"list[current_name;main;0,0;8,4;]"..
			"list[current_player;main;0,5;8,4;]"..
			"listring[current_name;main]"..
			"listring[current_player;main]")
		meta:set_string("infotext", "Chest")
		local inv = meta:get_inventory()
		inv:set_size("main", 8*4)
	end,
	can_dig = function(pos, player)
		local meta = minetest.get_meta(pos)
		local inv = meta:get_inventory()
		return inv:is_empty("main")
	end,
})


minetest.register_entity(":unknown_object", {
    initial_properties = {
        physical = true,
        visual = "sprite",
        visual_size = {x = 1, y = 1},
        textures = {"unknown_object.png"},
        collisionbox = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
        on_punch = function(self, puncher)
            -- Spawn a new entity when punched
            local pos = self.object:get_pos()
            local new_entity = minetest.add_entity(pos, "unknown_object")
            if new_entity then
                -- Give the puncher an item to spawn the entity
                local inv = puncher:get_inventory()
                inv:add_item("main", "2unknown_item")
            end
            self.object:remove()
        end,
    },
})

-- Register the spawn item

minetest.register_craftitem(":2unknown_item", {
    description = "Unknown Item",
    inventory_image = "unknown_item.png",
    on_place = function(itemstack, placer, pointed_thing)
        -- Spawn the entity when the spawn item is placed
        if pointed_thing.type == "node" then
            local pos = minetest.get_pointed_thing_position(pointed_thing, true)
            minetest.add_entity(pos, "unknown_object")
        end
        itemstack:take_item()
        return itemstack
    end,
})

-- Register the crafting recipe for the spawn item

minetest.register_craft({
    output = "sprite_entity_mod:spawn_item",
    recipe = {
        {"default:paper", "default:paper", "default:paper"},
        {"default:paper", "default:stick", "default:paper"},
        {"default:paper", "default:mese", "default:paper"},
    },
})


minetest.register_entity("default:2d", {
	initial_properties = {
		visual = "sprite",
		textures = { "testentities_sprite.png" },
    use_texture_alpha = true
	},
})

minetest.register_entity("default:playerfake", {
visual_size = {x=1, y=2},
	initial_properties = {
		visual = "upright_sprite",
		textures = {
			"player.png",
			"player_back.png",
		},
	},
})



-- Advanced visual tests

-- An entity for testing animated and yaw-modulated sprites
minetest.register_entity("default:yaw_test_dungeon_master", {
	initial_properties = {
		selectionbox = {-0.3, -0.5, -0.3, 0.3, 0.3, 0.3},
		visual = "sprite",
		visual_size = {x=0.6666, y=1},
		textures = {"dungeon_master.png^[makealpha:128,0,0^[makealpha:128,128,0"},
    use_texture_alpha = true,
		spritediv = {x=6, y=5},
		initial_sprite_basepos = {x=0, y=0},
	},
	on_activate = function(self, staticdata)
		self.object:set_sprite({x=0, y=0}, 3, 0.5, true)
	end,
})


minetest.register_entity("default:nametagnumber", {
	initial_properties = {
		visual = "sprite",
		textures = { "testentities_sprite.png" },
	},

	on_activate = function(self, staticdata)
		if staticdata ~= "" then
			local data = minetest.deserialize(staticdata)
			self.color = data.color
			self.bgcolor = data.bgcolor
		else
			self.color = {
				r = math.random(0, 255),
				g = math.random(0, 255),
				b = math.random(0, 255),
			}

			if math.random(0, 10) > 5 then
				self.bgcolor = {
					r = math.random(0, 255),
					g = math.random(0, 255),
					b = math.random(0, 255),
					a = math.random(0, 255),
				}
			end
		end

		assert(self.color)
		self.object:set_properties({
			nametag = tostring(math.random(0, 10000)),
		})
	end,
})



minetest.register_entity("default:logo", {
    initial_properties = {
        physical = true,
        visual = "sprite",
        visual_size = {x = 20, y = 1},
        textures = {"menulogo.png"},
        collisionbox = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
        on_punch = function(self, puncher)
            -- Spawn a new entity when punched
            local pos = self.object:get_pos()
            local new_entity = minetest.add_entity(pos, "default:logo")
            if new_entity then
                -- Give the puncher an item to spawn the entity
                local inv = puncher:get_inventory()
                inv:add_item("main", "logo")
            end
            self.object:remove()
        end,
    },
})

-- Register the spawn item

minetest.register_craftitem(":logo", {
    inventory_image = "menulogo.png",
    on_place = function(itemstack, placer, pointed_thing)
        -- Spawn the entity when the spawn item is placed
        if pointed_thing.type == "node" then
            local pos = minetest.get_pointed_thing_position(pointed_thing, true)
            minetest.add_entity(pos, "default:logo")
        end
        itemstack:take_item()
        return itemstack
    end,
})

minetest.register_craft({
    output = "logo",
    recipe = {
        {"default:gravel", "default:gravel", "default:gravel"},
        {"default:stick", "default:mese", "default:stick"},
        {"default:gravel", "default:gravel", "default:gravel"},
    }
})


minetest.register_craftitem("default:raat", {
    inventory_image = "raat.png",
    on_place = function(itemstack, placer, pointed_thing)
        -- Spawn the entity when the spawn item is placed
        if pointed_thing.type == "node" then
            local pos = minetest.get_pointed_thing_position(pointed_thing, true)
            minetest.add_entity(pos, "default:rat2")
        end
        itemstack:take_item()
        return itemstack
    end,
})

minetest.register_node("default:shadow_dirt", {
	description = "Shadow Dirt Block",
	tiles = {"sdd.png"},
    groups = {plastic = 5},
})

minetest.register_node("default:shadow_dirt_with_grass", {
	description = "Grass Block",
	tiles = {"sdg.png", "sdd.png", "sds.png"},
    groups = {plastic = 5},
})


minetest.register_node("default:shadowgen", {
	tiles = {"sdgen.png"},
	on_rightclick = function(pos, node, _)

	if minetest.get_modpath("default") then
		minetest.after(0.5, function()
        minetest.env:add_entity(pos, "default:oerkki2")
     minetest.env:add_entity(pos, "default:rat2")
   minetest.env:add_entity(pos, "default:oerkki1")
   minetest.set_node(pos, {name = "default:dirt_with_grass_footsteps"})
   minetest.sound_play("mese", {pos=pos, gain= 65535, max_hear_distance=50}, true)
		minetest.add_particlespawner(
			1, --amount
			1, --time
			{x=pos.x-1, y=pos.y, z=pos.z-1}, --minpos
			{x=pos.x+1, y=pos.y, z=pos.z+1}, --maxpos
			{x=-0, y=-0, z=-0}, --minvel
			{x=0, y=0, z=0}, --maxvel
			{x=-0.5,y=1,z=-0.5}, --minacc
			{x=0.5,y=1,z=0.5}, --maxacc
			1, --minexptime
			5, --maxexptime
			2, --minsize
           5, --maxsize
			true, --collisiondetection
			"smoke_puff.png" --texture
		)
		end)
		end
	end,
	groups = {plastic=3, not_in_creative_inventory=1},
})